//! Per-image walk state: geometry, sample offsets and the neighbour slots.
//!
//! `Frame` holds everything the model needs to know about *where* it is: the
//! current plane, row and pixel, plus a bank of neighbour slots (`nb0..nb57`).
//!
//! The neighbour slots are shift registers, not fixed positions. `begin_row`
//! loads the values that sit at the start of a row, `load_neighbours` refreshes
//! the few that change inside a row, and `advance_pixel` rotates the bank by one
//! pixel so that the next sample sees `left`, `left2`, ... and the rows above.
//! The `P(dx,dy)` annotations in the loaders give the position each freshly
//! loaded value comes from; a slot's position afterwards depends on how many
//! rotations have happened since, which is why the slots are numbered rather
//! than named after one geometry.

use super::DmModel;

#[inline]
pub fn abs32(v: i32) -> i32 {
    v.wrapping_abs()
}

pub struct Frame {
    // ---- geometry / position ------------------------------------------------
    pub w: i64,   // w
    pub h: i64,   // h
    pub stride: i64, // stride = 3*W
    pub stride3: i32,   // 9*W
    pub plane: i32,  // plane
    pub plane_count: i32,
    pub row_off: i64, // byte offset of the current row, channel `plane`
    pub px_off: i64,  // byte offset of the current pixel
    pub x: i64,  // x
    pub y: i64,  // y
    pub y_scan: i64,
    pub y_next: i64,
    pub x_next: i64,
    pub y16: i64,
    pub rate_base: i32,
    pub y_row: i64,
    pub prev_plane: u64,
    pub prev_plane_a: u64,
    /// Row-starts of the G plane while coding plane 1/0 (`t20`/`t1+plane`).
    pub green_row_off: i64,

    // ---- same-plane neighbours (u8) ----------------------------------------
    pub nb0: u8, pub nb1: u8, pub nb2: u8, pub nb3: u8, pub nb4: u8,
    pub nb5: u8, pub nb6: u8, pub nb7: u8, pub nb8: u8, pub nb9: u8,
    pub nb10: u8, pub nb11: u8, pub nb12: u8, pub nb13: u8, pub nb14: u8,
    pub nb15: u8, pub nb16: u8, pub nb17: u8, pub nb18: u8, pub nb19: u8,
    pub nb20: u8, pub nb21: u8, pub nb22: u8, pub nb23: u8, pub nb24: u8,
    pub nb25: u8,

    // ---- G-plane neighbours (u8) -------------------------------------------
    pub nb26: u8, pub nb27: u8, pub nb28: u8, pub nb29: u8, pub nb30: u8,
    pub nb31: u8, pub nb32: u8, pub nb33: u8, pub nb34: u8, pub nb35: u8,
    pub nb36: u8, pub nb37: u8, pub nb38: u8, pub nb39: u8, pub nb40: u8,
    pub nb41: u8, pub nb42: u8, pub nb43: u8, pub nb44: u8, pub nb45: u8,
    pub nb46: u8, pub nb47: u8, pub nb48: u8, pub nb49: u8, pub nb50: u8,

    // ---- B-plane neighbours (u8) -------------------------------------------
    pub nb51: u8, pub nb52: u8, pub nb53: u8, pub nb54: u8, pub nb55: u8,
    pub nb56: u8, pub nb57: u8,
}

impl Frame {
    pub fn new(w: usize, h: usize) -> Frame {
        Frame {
            w: w as i64,
            h: h as i64,
            stride: 3 * w as i64,
            stride3: 9 * w as i32,
            plane: 0, plane_count: 0, row_off: 0, px_off: 0,
            x: 0, y: 0, y_scan: 0, y_next: 0, x_next: 0, y16: 0, rate_base: 0,
            y_row: 0, prev_plane: 0, prev_plane_a: 0, green_row_off: 0,
            nb0: 0, nb1: 0, nb2: 0, nb3: 0, nb4: 0, nb5: 0, nb6: 0,
            nb7: 0, nb8: 0, nb9: 0, nb10: 0, nb11: 0, nb12: 0, nb13: 0,
            nb14: 0, nb15: 0, nb16: 0, nb17: 0, nb18: 0, nb19: 0, nb20: 0,
            nb21: 0, nb22: 0, nb23: 0, nb24: 0, nb25: 0,
            nb26: 0, nb27: 0, nb28: 0, nb29: 0, nb30: 0, nb31: 0, nb32: 0,
            nb33: 0, nb34: 0, nb35: 0, nb36: 0, nb37: 0, nb38: 0, nb39: 0,
            nb40: 0, nb41: 0, nb42: 0, nb43: 0, nb44: 0, nb45: 0, nb46: 0,
            nb47: 0, nb48: 0, nb49: 0, nb50: 0,
            nb51: 0, nb52: 0, nb53: 0, nb54: 0, nb55: 0, nb56: 0, nb57: 0,
        }
    }

    /// Reads one frame-buffer byte; out-of-range addresses behave as 0.
    #[inline]
    pub fn sample(buf: &[u8], off: i64) -> u8 {
        if off >= 0 && (off as usize) < buf.len() {
            buf[off as usize]
        } else {
            0
        }
    }
}

/// Clamp rule used by the predictor: 0..255 stays, below 0 becomes 0 and
/// above 255 becomes -1 (a sentinel, not a clamp).
#[inline]
pub fn clamp_sample(e: i32) -> i32 {
    if e > 255 {
        -1
    } else if e < 0 {
        0
    } else {
        e
    }
}

/// `abs(x-y)` on the byte-valued inputs.
#[inline]
fn absdiff(a: u8, b: u8) -> i32 {
    abs32(a as i32 - b as i32)
}

pub fn begin_sample(m: &mut DmModel, s: &Frame) {
    m.nctx = 0;
    m.c0 = 1;
    m.bitpos = 0;

    let t78 = ((s.x << 6) / s.w) as u8 as i32;
    let t79 = (if s.nb3 < s.nb0 { 0x10 } else { 0 })
        | (8 * (absdiff(s.nb0, s.nb3) >= 4) as i32)
        | (if s.nb3 < s.nb2 { 4 } else { 0 })
        | (absdiff(s.nb2, s.nb0) > 3) as i32
        | (if s.nb0 < s.nb2 { 2 } else { 0 });
    let mut t80 = 32;
    if absdiff(s.nb0, s.nb1) < 9 {
        t80 = 0;
    }
    let t81 = (if s.nb1 < s.nb0 { 0x40 } else { 0 }) | t80 | t79;
    let mut t82 = 0;
    if absdiff(s.nb2, s.nb7) > absdiff(s.nb0, s.nb5) {
        t82 = 128;
    }
    let t83 = ((t81 | t82) << 12)
        | ((((s.nb2 as i32) + (s.nb1 as i32)) >> 1) & 0xC0)
        | t78
        | ((s.y16 / s.h) as u8 as i32) << 8;
    m.ctx48 = t83;
}

pub fn advance_pixel(s: &mut Frame) {
    s.nb42 = s.nb36;
    s.nb41 = s.nb31;
    s.nb31 = s.nb32;
    s.nb32 = s.nb27;
    s.nb27 = s.nb34;
    s.nb36 = s.nb39;
    s.nb34 = s.nb35;
    s.nb35 = s.nb37;
    s.nb40 = s.nb29;
    s.nb29 = s.nb30;
    s.nb30 = s.nb28;
    s.nb28 = s.nb26;
    s.nb26 = s.nb33;
    s.x = s.x_next;
    s.nb37 = s.nb43;
    s.nb33 = s.nb38;
    s.nb22 = s.nb16;
    s.nb24 = s.nb4;
    s.nb4 = s.nb10;
    s.nb10 = s.nb19;
    let t84 = s.nb14;
    s.nb17 = s.nb5;
    s.nb14 = s.nb15;
    let t85 = s.nb3;
    s.nb19 = s.nb18;
    s.nb3 = s.nb0;
    s.nb5 = t84;
    s.nb21 = s.nb8;
    s.nb8 = t85;
    s.nb15 = s.nb20;
    s.nb0 = s.nb1;
    s.nb1 = s.nb6;
    s.nb6 = s.nb13;
    s.nb13 = s.nb9;
    s.nb23 = s.nb11;
    s.y_scan = s.y_row;
    s.nb11 = s.nb12;
    s.nb12 = s.nb7;
    s.nb7 = s.nb2;
}

pub fn next_plane(s: &mut Frame) {
    s.plane_count += 1;
    s.prev_plane = s.prev_plane_a;
    s.plane -= 1;
}

// ---------------------------------------------------------------------------
// The plane context sets and the neighbour loaders live in `contexts` and
// `neighbours`; they are re-exported here so the walk code has one import site.
// ---------------------------------------------------------------------------
pub use super::contexts::{ctx_blue, ctx_green, ctx_red};
pub use super::neighbours::{begin_row, load_neighbours};

pub fn end_of_row_rotate(s: &mut Frame, buf: &[u8]) {
    s.y = s.y_next;
    s.row_off += s.stride;
    begin_row(s, buf);
}
