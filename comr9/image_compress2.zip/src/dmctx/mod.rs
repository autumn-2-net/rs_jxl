//! Deepmix's proven context derivation and neighbour bank, adapted to a small
//! state struct so it can drive our own model. Original code is public domain
//! (unlicense), (c) the deepmix authors.

pub struct DmModel {
    pub ctx: [i32; 44],
    pub nctx: i32,
    pub c0: u8,
    pub bitpos: u8,
    pub ctx48: i32,
}

impl DmModel {
    pub fn new() -> Self {
        DmModel { ctx: [0; 44], nctx: 0, c0: 1, bitpos: 0, ctx48: 0 }
    }
}

impl Default for DmModel {
    fn default() -> Self {
        Self::new()
    }
}

pub mod contexts;
pub mod frame;
pub mod neighbours;

pub use contexts::*;
pub use frame::*;
pub use neighbours::*;
