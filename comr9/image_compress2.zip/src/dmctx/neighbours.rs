//! Neighbour loading: row start and per-pixel refresh.
//!
//! `begin_row` fills the neighbour bank when the walk enters row `y` of the
//! current plane; `load_neighbours` refreshes the in-row values for the current
//! pixel. Both are written as straight-line code with early exits, mirroring the
//! dependency structure of the definition: out-of-frame neighbours are 0, and
//! the first rows of an image use shorter neighbourhoods.

use super::Frame;

pub fn load_neighbours(s: &mut Frame, buf: &[u8]) {
    if s.x != 0 {
        s.nb2 = Frame::sample(buf, s.px_off - 3); /* P(x-1,y) */
    } else {
        s.nb2 = 0;
    }

    'done: {
        if s.y_scan == 0 {
            s.nb16 = 0;
            s.nb18 = 0;
            s.nb20 = 0;
            s.nb9 = 0;
            s.nb25 = 0;
            s.x_next = s.x + 1;
            break 'done;
        }

        if s.w <= s.x + 4 {
            s.nb9 = 0;
        } else {
            s.nb9 = Frame::sample(buf, s.px_off - s.stride + 12); /* P(x+4,y-1) */
        }

        if s.y_scan <= 1 {
            s.nb16 = 0;
            s.nb18 = 0;
            s.nb20 = 0;
            s.nb25 = 0;
            s.x_next = s.x + 1;
            break 'done;
        }

        'shared: {
            if s.x + 3 >= s.w {
                s.nb20 = 0;
                s.nb18 = 0;
                if s.y_scan == 2 {
                    break 'shared;
                }
            } else {
                s.nb20 = Frame::sample(buf, s.px_off + 9 - 2 * s.stride); /* P(x+3,y-2) */
                if s.y_scan == 2 {
                    s.nb16 = 0;
                    s.nb18 = 0;
                    s.nb25 = 0;
                    s.x_next = s.x + 1;
                    break 'done;
                }
                s.nb18 = Frame::sample(buf, s.px_off + 9 - 3 * s.stride); /* P(x+3,y-3) */
            }

            if s.y_scan <= 3 {
                break 'shared;
            }

            s.x_next = s.x + 1;
            if s.w <= s.x + 1 {
                s.nb16 = 0;
            } else {
                s.nb16 = Frame::sample(buf, s.px_off + 3 - 4 * s.stride); /* P(x+1,y-4) */
            }
            if s.y_scan == 4 {
                s.nb25 = 0;
            } else {
                s.nb25 = Frame::sample(buf, s.px_off - 5 * s.stride); /* P(x,y-5) */
            }
            break 'done;
        }

        s.nb16 = 0;
        s.nb25 = 0;
        s.x_next = s.x + 1;
    }
}

pub fn begin_row(s: &mut Frame, buf: &[u8]) {
    let mut t303: u8;
    let mut t304: u8;
    let t305: i64; // char *t305 -- kept as a byte offset into the frame buffer
    let t302: i64;
    let t306: i64; // == 6*y, only in the W==2 same-plane branch ()

    'skip: {
        if s.y == 0 {
            s.nb22 = 0;
            s.nb19 = 0;
            s.nb10 = 0;
            s.nb4 = 0;
            s.nb15 = 0;
            s.nb14 = 0;
            s.nb5 = 0;
            s.nb13 = 0;
            s.nb6 = 0;
            s.nb1 = 0;
            s.nb0 = 0;
            break 'skip;
        }
        s.nb0 = Frame::sample(buf, s.row_off - s.stride); /* P(0,y-1) */

        if s.w <= 1 {
            if s.y <= 1 {
                s.nb22 = 0;
                s.nb19 = 0;
                s.nb10 = 0;
                s.nb4 = 0;
                s.nb15 = 0;
                s.nb14 = 0;
                s.nb5 = 0;
                s.nb13 = 0;
                s.nb6 = 0;
                s.nb1 = 0;
                break 'skip;
            }
            s.nb5 = Frame::sample(buf, s.row_off - 2 * s.stride);
            if s.y == 2 {
                s.nb22 = 0;
                s.nb19 = 0;
                s.nb10 = 0;
                s.nb4 = 0;
                s.nb15 = 0;
                s.nb14 = 0;
                s.nb13 = 0;
                s.nb6 = 0;
                s.nb1 = 0;
                break 'skip;
            }
            s.nb15 = 0;
            s.nb14 = 0;
            s.nb13 = 0;
            s.nb6 = 0;
            s.nb1 = 0;
            s.nb19 = 0;
            s.nb10 = 0;
            s.nb4 = Frame::sample(buf, s.row_off - 3 * s.stride);
        } else {
            s.nb1 = Frame::sample(buf, s.row_off - s.stride + 3); /* P(1,y-1) */
            if s.w == 2 {
                if s.y <= 1 {
                    s.nb22 = 0;
                    s.nb19 = 0;
                    s.nb10 = 0;
                    s.nb4 = 0;
                    s.nb15 = 0;
                    s.nb14 = 0;
                    s.nb5 = 0;
                    s.nb13 = 0;
                    s.nb6 = 0;
                    break 'skip;
                }
                t306 = 6 * s.y;
                s.nb5 = Frame::sample(buf, s.green_row_off + 6 * s.y - 12); /* P(0,y-2) */
                s.nb14 = Frame::sample(buf, s.green_row_off + 6 * s.y - 9); /* P(1,y-2) */
                if s.y == 2 {
                    s.nb22 = 0;
                    s.nb19 = 0;
                    s.nb10 = 0;
                    s.nb4 = 0;
                    s.nb15 = 0;
                    s.nb13 = 0;
                    s.nb6 = 0;
                    break 'skip;
                }
                s.nb15 = 0;
                s.nb13 = 0;
                s.nb6 = 0;
                s.nb19 = 0;
                s.nb4 = Frame::sample(buf, s.green_row_off + t306 - 18); /* P(0,y-3) */
                s.nb10 = Frame::sample(buf, s.green_row_off + t306 - 15); /* P(1,y-3) */
            } else {
                s.nb6 = Frame::sample(buf, s.row_off - s.stride + 6); /* P(2,y-1) */
                if s.w == 3 {
                    s.nb13 = 0;
                } else {
                    s.nb13 = Frame::sample(buf, s.row_off - s.stride + 9); /* P(3,y-1) */
                }
                if s.y <= 1 {
                    s.nb22 = 0;
                    s.nb19 = 0;
                    s.nb10 = 0;
                    s.nb4 = 0;
                    s.nb15 = 0;
                    s.nb14 = 0;
                    s.nb5 = 0;
                    break 'skip;
                }
                s.nb5 = Frame::sample(buf, s.row_off - 2 * s.stride);
                s.nb14 = Frame::sample(buf, s.row_off - 2 * s.stride + 3);
                s.nb15 = Frame::sample(buf, s.row_off - 2 * s.stride + 6);
                if s.y == 2 {
                    s.nb22 = 0;
                    s.nb19 = 0;
                    s.nb10 = 0;
                    s.nb4 = 0;
                    break 'skip;
                }
                s.nb4 = Frame::sample(buf, s.row_off - 3 * s.stride);
                s.nb10 = Frame::sample(buf, s.row_off - 3 * s.stride + 3);
                s.nb19 = Frame::sample(buf, s.row_off - 3 * s.stride + 6);
            }
        }
        if s.y == 3 {
            s.nb22 = 0;
        } else {
            s.nb22 = Frame::sample(buf, s.row_off - 4 * s.stride); /* P(0,y-4) */
        }
    }

    if s.plane != 2 {
        s.nb33 = Frame::sample(buf, s.row_off + (s.plane_count + 2) as i64); /* G(0,y) */
        if s.y != 0 {
            t305 = s.row_off - s.plane as i64; /* = buf + 3*y*W */
            s.nb27 = Frame::sample(buf, s.row_off - s.plane as i64 - s.stride + 2);
            if s.w <= 1 {
                s.nb36 = 0;
                if s.y <= 1 {
                    s.nb42 = 0;
                    s.nb37 = 0;
                    s.nb35 = 0;
                    s.nb34 = 0;
                } else {
                    s.nb37 = 0;
                    s.nb35 = 0;
                    s.nb34 = 0;
                    s.nb42 = Frame::sample(buf, t305 - 2 * s.stride + 2);
                }
            } else {
                s.nb34 = Frame::sample(buf, t305 - s.stride + 5); /* G(1,y-1) */
                if s.w == 2 {
                    if s.y <= 1 {
                        s.nb36 = 0;
                        s.nb42 = 0;
                        s.nb37 = 0;
                        s.nb35 = 0;
                    } else {
                        s.nb35 = 0;
                        s.nb37 = 0;
                        t302 = 6 * s.y - 12;
                        s.nb42 = Frame::sample(buf, 6 * s.y - 10);
                        s.nb36 = Frame::sample(buf, t302 + 5);
                    }
                } else {
                    s.nb35 = Frame::sample(buf, t305 - s.stride + 8);
                    if s.w == 3 {
                        s.nb37 = 0;
                    } else {
                        s.nb37 = Frame::sample(buf, t305 - s.stride + 11);
                    }
                    if s.y > 1 {
                        t302 = s.row_off - 2 * s.stride - s.plane as i64;
                        s.nb42 = Frame::sample(buf, t305 - 2 * s.stride + 2);
                        s.nb36 = Frame::sample(buf, t302 + 5);
                    } else {
                        s.nb36 = 0;
                        s.nb42 = 0;
                    }
                }
            }
        } else {
            s.nb36 = 0;
            s.nb42 = 0;
            s.nb35 = 0;
            s.nb34 = 0;
            s.nb27 = 0;
        }
        s.nb31 = 0;
        t303 = s.nb54;
        s.nb32 = 0;
        t304 = s.nb51;
        s.nb41 = 0;
        s.nb26 = 0;
        s.nb28 = 0;
        if s.plane == 0 {
            t303 = 0;
        }
        s.nb30 = 0;
        if s.plane == 0 {
            t304 = 0;
        }
        s.nb29 = 0;
        s.nb40 = 0;
        s.nb54 = t303;
        s.nb51 = t304;
    }

    s.nb3 = 0;
    s.y_scan = s.y;
    s.y_next = s.y + 1;
    s.px_off = s.row_off;
    s.y16 = 16 * s.y;
    s.nb24 = 0;
    s.rate_base = 5 - (s.y < 5) as i32;
    s.x = 0;
    s.nb17 = 0;
    s.nb8 = 0;
    s.nb21 = 0;
    s.nb7 = 0;
    s.nb12 = 0;
    s.nb11 = 0;
}
