//! Context derivation for the three colour planes.
//!
//! One function per plane. Each turns the neighbour bank into the list of
//! context indices the model then mixes (`m.ctx[0..nctx]`): quantised gradient
//! signs, edge-detector outputs, predictor values, and - for the red and blue
//! planes - residuals against already coded samples of the same pixel and of
//! the green plane.
//!
//! The shared opening (`begin_sample`) resets the tree state and computes the
//! 8-bit neighbourhood descriptor `ctx48` that four of the mixer stages use as
//! a selector.

use super::{abs32, load_neighbours, Frame, DmModel};

/// Number of deepmix contexts the active configuration can use (the last four
/// slots hold the cheap anime contexts). Used to skip the tail of each
/// per-plane derivation when the context budget is small.
pub fn ctx_need() -> usize {
    static N: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    *N.get_or_init(|| {
        let cap = std::env::var("ACM_NCTX")
            .or_else(|_| std::env::var("R4_NCTX"))
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .unwrap_or(48)
            .clamp(1, 48);
        cap.saturating_sub(4)
    })
}


pub fn ctx_green(m: &mut DmModel, s: &mut Frame, buf: &[u8]) {
    load_neighbours(s, buf);

    m.nctx = 0;
    m.c0 = 1;
    m.bitpos = 0;
    let t78: i32 = ((s.x << 6) / s.w) as u8 as i32;
    let t86: i32 = s.nb2 as i32 + s.nb1 as i32;
    let t79: i32 = (if s.nb3 < s.nb0 { 0x10 } else { 0 })
        | (8 * ((abs32(s.nb0 as i32 - s.nb3 as i32) >= 4) as i32))
        | (if s.nb3 < s.nb2 { 4 } else { 0 })
        | ((abs32(s.nb2 as i32 - s.nb0 as i32) > 3) as i32)
        | (if s.nb0 < s.nb2 { 2 } else { 0 });
    let mut t82: i32 = 0;
    let mut t80: i32 = 32;
    if abs32(s.nb0 as i32 - s.nb1 as i32) < 9 {
        t80 = 0;
    }
    let t81: i32 = (if s.nb1 < s.nb0 { 0x40 } else { 0 }) | t80 | t79;
    if abs32(s.nb2 as i32 - s.nb7 as i32) > abs32(s.nb0 as i32 - s.nb5 as i32) {
        t82 = 128;
    }
    let t83: i32 = ((t81 | t82) << 12)
        | (((s.nb2 as i32 + s.nb1 as i32) >> 1) & 0xC0)
        | t78
        | (((s.y16 / s.h) as u8 as i32) << 8);
    let mut t87: i32 = s.nb6 as i32;
    let t88: i32 = 2 * s.nb2 as i32;
    m.ctx48 = t83;

    let mut t89: i32 = s.nb2 as i32;
    let mut t90: i32 = s.nb2 as i32;
    let t91: i32 = 2 * s.nb2 as i32 - s.nb7 as i32;
    if s.nb0 < s.nb2 {
        t90 = s.nb0 as i32;
    }
    if s.nb0 > s.nb2 {
        t89 = s.nb0 as i32;
    }
    if s.nb1 as i32 <= s.nb6 as i32 {
        t87 = s.nb1 as i32;
    }
    if t87 > t90 {
        t87 = t90;
    }
    if t91 >= t87 {
        t87 = s.nb6 as i32;
        if s.nb1 as i32 >= s.nb6 as i32 {
            t87 = s.nb1 as i32;
        }
        if t87 < t89 {
            t87 = t89;
        }
        if t91 <= t87 {
            t87 = 2 * s.nb2 as i32 - s.nb7 as i32;
        }
    }
    let t92: i32 = 11264 * (t87 as u8 as i32);
    let mut t93: i32 = s.nb3 as i32;
    m.ctx[0] = t92;
    let t94: i32 = 2 * s.nb0 as i32 - s.nb5 as i32;
    let mut t95: i32 = s.nb3 as i32;
    if s.nb3 <= s.nb2 {
        t95 = s.nb2 as i32;
    }
    if s.nb0 as i32 >= t95 {
        t95 = s.nb0 as i32;
    }
    if s.nb3 >= s.nb2 {
        t93 = s.nb2 as i32;
    }
    let t96: i32 = t95;
    if s.nb0 as i32 <= t93 {
        t93 = s.nb0 as i32;
    }
    let t97: i32 = t93;
    if s.nb1 as i32 <= t93 {
        t93 = s.nb1 as i32;
    }
    if t94 >= t93 {
        t93 = t95;
        if s.nb1 as i32 >= t95 {
            t93 = s.nb1 as i32;
        }
        if t94 <= t93 {
            t93 = 2 * s.nb0 as i32 - s.nb5 as i32;
        }
    }
    let mut t98: i8 = -1;
    let t99: i32 = s.nb2 as i32 + s.nb0 as i32 - s.nb3 as i32;
    m.ctx[1] = 11264 * (t93 as u8 as i32) + 1;
    if t99 <= 255 {
        t98 = 0;
        if t99 >= 0 {
            t98 = (s.nb2 as i32 + s.nb0 as i32 - s.nb3 as i32) as i8;
        }
    }
    let t100: i32 = t86 - s.nb0 as i32;
    let mut t101: u8 = -1i8 as u8;
    m.ctx[2] = 11264
        * (((s.nb17 as i32 + s.nb0 as i32 - s.nb5 as i32 - s.nb3 as i32) as u8 as i32) >> 7
            | ((t98 as i32) & 0xFE))
        + 2;
    if t100 <= 255 {
        t101 = 0;
        if t100 >= 0 {
            t101 = t100 as u8;
        }
    }
    let t102: i32 = t101 as i32;
    let mut t103: u8 = -1i8 as u8;
    m.ctx[3] = 11264 * t102 + 3;
    let t104: i32 = s.nb10 as i32 + -3 * s.nb14 as i32 + 3 * s.nb1 as i32;
    if t104 <= 255 {
        t103 = 0;
        if t104 >= 0 {
            t103 = (s.nb10 as i32 + -3 * s.nb14 as i32 + 3 * s.nb1 as i32) as u8;
        }
    }
    let mut t105: i8 = -1;
    m.ctx[4] = 11264 * ((s.nb2 as i32 + t103 as i32) >> 1) + 4;
    let t106: i32 = s.nb12 as i32 + -3 * s.nb7 as i32 + 3 * s.nb2 as i32;
    if t106 <= 255 {
        t105 = 0;
        if t106 >= 0 {
            t105 = (s.nb12 as i32 + -3 * s.nb7 as i32 + 3 * s.nb2 as i32) as i8;
        }
    }
    let t107: i32 = 11264 * ((t105 as i32) & 0xFC);
    let mut t108: i8 = -1;
    let t109: i32 = s.nb4 as i32 + -3 * s.nb5 as i32 + 3 * s.nb0 as i32;
    m.ctx[5] = t107 + 5;
    if t109 <= 255 {
        t108 = 0;
        if t109 >= 0 {
            t108 = (s.nb4 as i32 + -3 * s.nb5 as i32 + 3 * s.nb0 as i32) as i8;
        }
    }
    m.ctx[6] = 11264 * ((t108 as i32) & 0xFC) + 6;
    m.ctx[8] = 11264 * s.nb2 as i32 + 8;
    let mut t110: i8 = -1;
    m.ctx[7] = 11264 * ((s.nb6 as i32 + s.nb7 as i32) >> 1) + 7;
    if ctx_need() <= 8 {
        m.nctx = 8;
        return;
    }
    m.ctx[9] = 11264 * s.nb0 as i32 + 9;
    let t111: i32 = (3 * (s.nb2 as i32 + s.nb0 as i32) - 2 * s.nb3 as i32) / 4;
    if t111 <= 255 {
        t110 = 0;
        if t111 >= 0 {
            t110 = ((3 * (s.nb2 as i32 + s.nb0 as i32) - 2 * s.nb3 as i32) / 4) as i8;
        }
    }
    m.ctx[10] = 11264 * ((t110 as i32) & 0xFE) + 10;
    let t112: i32 = -6 * s.nb14 as i32 + 4 * s.nb1 as i32 + 4 * s.nb10 as i32 - s.nb16 as i32;
    let mut t113: i32 = s.nb6 as i32;
    let mut t114: i32 = s.nb0 as i32;
    let mut t115: i32 = s.nb0 as i32;
    if s.nb0 > s.nb1 {
        t115 = s.nb1 as i32;
    }
    if s.nb0 < s.nb1 {
        t114 = s.nb1 as i32;
    }
    if s.nb13 as i32 <= s.nb6 as i32 {
        t113 = s.nb13 as i32;
    }
    if t113 > t115 {
        t113 = t115;
    }
    if t112 >= t113 {
        t113 = s.nb6 as i32;
        if s.nb13 as i32 >= s.nb6 as i32 {
            t113 = s.nb13 as i32;
        }
        if t113 < t114 {
            t113 = t114;
        }
        if t112 <= t113 {
            t113 = -6 * s.nb14 as i32 + 4 * s.nb1 as i32 + 4 * s.nb10 as i32 - s.nb16 as i32;
        }
    }
    let mut t116: i8 = -1;
    let t117: i32 = ((t113 as u8 as i32) + 10 * s.nb2 as i32 - 10 * s.nb7 as i32
        + 5 * s.nb12 as i32
        - s.nb11 as i32)
        / 5;
    if t117 <= 255 {
        t116 = 0;
        if t117 >= 0 {
            t116 = (((t113 as u8 as i32) + 10 * s.nb2 as i32 - 10 * s.nb7 as i32
                + 5 * s.nb12 as i32
                - s.nb11 as i32)
                / 5) as i8;
        }
    }
    m.ctx[11] = 11264 * ((t116 as i32) & 0xFE) + 11;
    if ctx_need() <= 12 {
        m.nctx = 12;
        return;
    }
    let t118: i32 = (6 * s.nb1 as i32 + s.nb18 as i32 - 4 * s.nb15 as i32 - 6 * s.nb3 as i32
        + 4 * s.nb2 as i32
        + 4 * s.nb17 as i32
        - s.nb24 as i32)
        / 4;
    let mut t119: i8 = -1;
    if t118 <= 255 {
        t119 = 0;
        if t118 >= 0 {
            t119 = ((6 * s.nb1 as i32 + s.nb18 as i32 - 4 * s.nb15 as i32 - 6 * s.nb3 as i32
                + 4 * s.nb2 as i32
                + 4 * s.nb17 as i32
                - s.nb24 as i32)
                / 4) as i8;
        }
    }
    let t120: i32 = s.nb6 as i32 + s.nb7 as i32 - s.nb0 as i32;
    let mut t121: u8 = -1i8 as u8;
    m.ctx[12] = 11264 * ((t119 as i32) & 0xFE) + 12;
    if t120 <= 255 {
        t121 = 0;
        if t120 >= 0 {
            t121 = (s.nb6 as i32 + s.nb7 as i32 - s.nb0 as i32) as u8;
        }
    }
    let mut t122: i32 = s.nb9 as i32;
    m.ctx[14] = 11264 * s.nb5 as i32 + 14;
    m.ctx[13] = 11264 * (t121 as i32) + 13;
    let mut t123: i32 = s.nb6 as i32;
    let t124: i32 = s.nb19 as i32 + 3 * s.nb6 as i32 - 3 * s.nb15 as i32;
    let mut t125: i32 = s.nb6 as i32;
    let mut t126: i32 = s.nb9 as i32;
    if s.nb1 <= s.nb6 {
        t123 = s.nb1 as i32;
    }
    if s.nb1 >= s.nb6 {
        t125 = s.nb1 as i32;
    }
    if s.nb13 as i32 <= s.nb9 as i32 {
        t126 = s.nb13 as i32;
    }
    if t126 > t123 {
        t126 = t123;
    }
    if t124 >= t126 {
        if s.nb13 as i32 >= s.nb9 as i32 {
            t122 = s.nb13 as i32;
        }
        if t122 < t125 {
            t122 = t125;
        }
        t126 = t122;
        if t124 <= t122 {
            t126 = s.nb19 as i32 + 3 * s.nb6 as i32 - 3 * s.nb15 as i32;
        }
    }
    let mut t127: i8 = -1;
    let t128: i32 = ((t126 as u8 as i32) + -3 * s.nb7 as i32 + 8 * s.nb2 as i32) / 6;
    if t128 <= 255 {
        t127 = 0;
        if t128 >= 0 {
            t127 = (((t126 as u8 as i32) + -3 * s.nb7 as i32 + 8 * s.nb2 as i32) / 6) as i8;
        }
    }
    let mut t129: u8 = -1i8 as u8;
    m.ctx[15] = 11264 * ((t127 as i32) & 0xFE) + 15;
    if t112 <= 255 {
        t129 = 0;
        if t112 >= 0 {
            t129 = (-6 * s.nb14 as i32 + 4 * s.nb1 as i32 + 4 * s.nb10 as i32 - s.nb16 as i32)
                as u8;
        }
    }
    let mut t130: i8 = -1;
    let t131: i32 = (6 * s.nb2 as i32 + s.nb12 as i32 - 4 * s.nb7 as i32 + t129 as i32) / 4;
    if t131 <= 255 {
        t130 = 0;
        if t131 >= 0 {
            t130 = ((6 * s.nb2 as i32 + s.nb12 as i32 - 4 * s.nb7 as i32 + t129 as i32) / 4) as i8;
        }
    }
    m.ctx[16] = 11264 * ((t130 as i32) & 0xFC) + 16;
    let mut t132: i32 = t97;
    let t133: i32 = t88 - s.nb8 as i32;
    if s.nb5 as i32 <= t97 {
        t132 = s.nb5 as i32;
    }
    if t133 >= t132 {
        t132 = t96;
        if s.nb5 as i32 >= t96 {
            t132 = s.nb5 as i32;
        }
        if t133 <= t132 {
            t132 = t88 - s.nb8 as i32;
        }
    }
    let mut t134: i8 = -1;
    let t135: i32 = ((t132 as u8 as i32) + 15 * s.nb0 as i32 - 20 * s.nb5 as i32
        + 15 * s.nb4 as i32
        + s.nb25 as i32
        - 6 * s.nb22 as i32)
        / 6;
    if t135 <= 255 {
        t134 = 0;
        if t135 >= 0 {
            t134 = (((t132 as u8 as i32) + 15 * s.nb0 as i32 - 20 * s.nb5 as i32
                + 15 * s.nb4 as i32
                + s.nb25 as i32
                - 6 * s.nb22 as i32)
                / 6) as i8;
        }
    }
    let mut t136: u8 = -1i8 as u8;
    let t137: i32 = s.nb0 as i32 + s.nb12 as i32 - s.nb21 as i32;
    m.ctx[17] = 11264 * ((t134 as i32) & 0xFC) + 17;
    if t137 <= 255 {
        t136 = 0;
        if t137 >= 0 {
            t136 = (s.nb0 as i32 + s.nb12 as i32 - s.nb21 as i32) as u8;
        }
    }
    m.ctx[18] = 11264 * (t136 as i32) + 18;
    m.ctx[19] = 11264 * s.nb14 as i32 + 19;
    m.ctx[23] = 11264 * s.nb11 as i32 + 23;
    m.ctx[21] = 11264 * s.nb7 as i32 + 21;
    m.ctx[22] = 11264 * s.nb13 as i32 + 22;
    m.ctx[20] = 11264 * s.nb6 as i32 + 20;
    let mut t138: i32 = (s.nb0 as i32) >> 2;
    t138 |= 0x800;
    m.ctx[24] = 11264 * (((s.nb2 as i32) >> 1) | ((16 * s.nb7 as i32) & 0xF80)) + 24;
    m.ctx[25] = 11264 * (((s.nb0 as i32) >> 1) | ((16 * s.nb5 as i32) & 0xF80)) + 25;
    m.ctx[26] = 11264 * (t138 | ((8 * s.nb4 as i32) & 0x7C0)) + 26;
    m.ctx[27] = 11264 * (((s.nb2 as i32) >> 2) | ((16 * s.nb12 as i32) & 0xFC0)) + 27;
    m.ctx[29] = 11264 * ((t78 >> 3) | ((s.nb1 as i32) & 0xF8)) + 29;
    m.ctx[28] = 11264 * ((t78 >> 5) | ((s.nb3 as i32) & 0xFE)) + 28;
    m.ctx[31] = 11264 * ((s.nb8 as i32) & 0xFE) + 31;
    m.ctx[30] = 11264
        * (((16 * s.nb2 as i32) & 0xF00) | ((s.nb0 as i32) & 0xF0) | ((s.nb1 as i32) >> 4))
        + 30;
    m.ctx[32] = 11264 * ((s.nb23 as i32) & 0xFE) + 32;
    let mut t139: i8 = -1;
    let t140: i32 = s.nb7 as i32 + s.nb2 as i32 - s.nb12 as i32;
    m.ctx[33] = 11264 * ((s.nb9 as i32) & 0xFE) + 33;
    if t140 <= 255 {
        t139 = 0;
        if t140 >= 0 {
            t139 = (s.nb7 as i32 + s.nb2 as i32 - s.nb12 as i32) as i8;
        }
    }
    let mut t141: i8 = -1;
    let t142: i32 = s.nb5 as i32 + s.nb0 as i32 - s.nb4 as i32;
    m.ctx[34] = 11264 * ((t139 as i32) & 0xFC) + 34;
    if t142 <= 255 {
        t141 = 0;
        if t142 >= 0 {
            t141 = (s.nb5 as i32 + s.nb0 as i32 - s.nb4 as i32) as i8;
        }
    }
    m.nctx = 37;

    s.nb39 = s.nb36;
    m.ctx[35] = 11264 * (((t141 as i32) & 0xFC) | 2) + 35;
    s.nb36 = s.nb42;
    s.nb43 = s.nb37;
    m.ctx[36] = 11264 * ((s.nb4 as i32) & 0xFE) + 36;
    s.nb37 = s.nb35;
    s.nb35 = s.nb34;
    s.nb34 = s.nb27;
    s.nb27 = s.nb32;
    s.nb32 = s.nb31;
    s.nb38 = s.nb33;
    s.nb33 = s.nb26;
    s.nb31 = s.nb41;
    s.nb26 = s.nb28;
    s.nb28 = s.nb30;
    s.nb30 = s.nb29;
    s.nb29 = s.nb40;
}

pub fn ctx_red(m: &mut DmModel, s: &mut Frame, buf: &[u8]) {
    load_neighbours(s, buf);

    m.nctx = 0;
    m.c0 = 1;
    m.bitpos = 0;
    let t78: i32 = ((s.x << 6) / s.w) as u8 as i32;
    let t86: i32 = s.nb2 as i32 + s.nb1 as i32;
    let t79: i32 = (if s.nb3 < s.nb0 { 0x10 } else { 0 })
        | (8 * ((abs32(s.nb0 as i32 - s.nb3 as i32) >= 4) as i32))
        | (if s.nb3 < s.nb2 { 4 } else { 0 })
        | ((abs32(s.nb2 as i32 - s.nb0 as i32) > 3) as i32)
        | (if s.nb0 < s.nb2 { 2 } else { 0 });
    let mut t82: i32 = 0;
    let mut t80: i32 = 32;
    if abs32(s.nb0 as i32 - s.nb1 as i32) < 9 {
        t80 = 0;
    }
    let t81: i32 = (if s.nb1 < s.nb0 { 0x40 } else { 0 }) | t80 | t79;
    if abs32(s.nb2 as i32 - s.nb7 as i32) > abs32(s.nb0 as i32 - s.nb5 as i32) {
        t82 = 128;
    }
    let t83: i32 = ((t81 | t82) << 12)
        | (((s.nb2 as i32 + s.nb1 as i32) >> 1) & 0xC0)
        | t78
        | (((s.y16 / s.h) as u8 as i32) << 8);
    let t88: i32 = 2 * s.nb2 as i32;
    m.ctx48 = t83;

    if s.h <= s.y_next {
        s.nb50 = 0;
    } else {
        s.nb50 = Frame::sample(buf, s.px_off + s.stride + 2);
    }
    if s.w <= s.x_next {
        s.nb38 = 0;
    } else {
        s.nb38 = Frame::sample(buf, s.px_off + 5);
    }
    s.nb53 = Frame::sample(buf, s.px_off + 1);

    'alt_b: {
        'alt_c: {
            if s.y_scan != 0 {
                if s.w <= s.x + 4 {
                    s.nb43 = 0;
                } else {
                    s.nb43 = Frame::sample(buf, s.px_off - s.stride + 14);
                }
                if s.y_scan <= 1 {
                    s.nb55 = 0;
                    s.nb49 = 0;
                    s.nb47 = 0;
                    s.nb39 = 0;
                } else {
                    if s.w <= s.x + 2 {
                        s.nb39 = 0;
                    } else {
                        s.nb39 = Frame::sample(buf, s.px_off + 8 - 2 * s.stride);
                    }
                    if s.y_scan == 2 {
                        s.nb55 = 0;
                        s.nb49 = 0;
                        s.nb47 = 0;
                    } else {
                        s.nb47 = Frame::sample(buf, s.px_off - s.stride3 as i64 + 2);
                        if s.w <= s.x + 3 {
                            s.nb49 = 0;
                        } else {
                            s.nb49 = Frame::sample(buf, s.px_off - s.stride3 as i64 + 11);
                        }
                        if s.y_scan == 3 {
                            s.nb55 = 0;
                        } else {
                            s.nb55 = Frame::sample(buf, s.px_off + 2 - 4 * s.stride);
                            if s.y_scan != 4 {
                                s.nb57 = Frame::sample(buf, s.px_off + 2 - 5 * s.stride);
                                break 'alt_c;
                            }
                        }
                    }
                }
                s.nb57 = 0;
            } else {
                s.nb57 = 0;
                s.nb55 = 0;
                s.nb49 = 0;
                s.nb47 = 0;
                s.nb39 = 0;
                s.nb43 = 0;
                s.nb56 = 0;
                break 'alt_b;
            }
        }

        if s.w <= s.x_next {
            s.nb56 = 0;
        } else {
            s.nb56 = Frame::sample(buf, s.px_off - s.stride + 4);
        }
    }

    let mut t143: u8 = -1i8 as u8;
    let mut t144: i32 = s.nb26 as i32;
    let t145: i32 = s.nb2 as i32 + s.nb33 as i32 - s.nb26 as i32;
    if t145 <= 255 {
        t143 = 0;
        if t145 >= 0 {
            t143 = (s.nb2 as i32 + s.nb33 as i32 - s.nb26 as i32) as u8;
        }
    }
    let t146: i32 = t143 as i32;
    let mut t147: u8 = -1i8 as u8;
    let t148: i32 = s.nb0 as i32 + s.nb33 as i32 - s.nb27 as i32;
    m.ctx[0] = 11264 * t146;
    if t148 <= 255 {
        t147 = 0;
        if t148 >= 0 {
            t147 = (s.nb0 as i32 + s.nb33 as i32 - s.nb27 as i32) as u8;
        }
    }
    m.ctx[1] = 11264 * (t147 as i32) + 1;
    let mut t149: i8 = -1;
    let t150: i32 = s.nb2 as i32 + s.nb0 as i32 - s.nb3 as i32;
    let t151: i32 = s.nb33 as i32 + t150 - (s.nb26 as i32 + s.nb27 as i32 - s.nb32 as i32);
    if t151 <= 255 {
        t149 = 0;
        if t151 >= 0 {
            t149 = (s.nb33 as i32 + t150 - (s.nb26 as i32 + s.nb27 as i32 - s.nb32 as i32)) as i8;
        }
    }
    let mut t152: u8 = -1i8 as u8;
    m.ctx[2] = 11264
        * (((s.nb0 as i32 + s.nb17 as i32 - s.nb5 as i32 - s.nb3 as i32) as u8 as i32) >> 7
            | ((t149 as i32) & 0xFE))
        + 2;
    let t153: i32 = s.nb33 as i32 + t86 - s.nb0 as i32
        - (s.nb26 as i32 + s.nb34 as i32 - s.nb27 as i32);
    if t153 <= 255 {
        t152 = 0;
        if t153 >= 0 {
            t152 = t153 as u8;
        }
    }
    let mut t154: u8 = -1i8 as u8;
    let t155: i32 = 2 * s.nb1 as i32 - s.nb14 as i32;
    m.ctx[3] = 11264 * (t152 as i32) + 3;
    if t155 <= 255 {
        t154 = 0;
        if t155 >= 0 {
            t154 = (2 * s.nb1 as i32 - s.nb14 as i32) as u8;
        }
    }
    let t156: i32 = s.nb12 as i32 + -3 * s.nb7 as i32 + 3 * s.nb2 as i32;
    m.ctx[4] = 11264 * ((s.nb2 as i32 + t154 as i32) >> 1) + 4;
    let mut t157: i8 = -1;
    if t156 <= 255 {
        t157 = 0;
        if t156 >= 0 {
            t157 = (s.nb12 as i32 + -3 * s.nb7 as i32 + 3 * s.nb2 as i32) as i8;
        }
    }
    let t158: i32 = s.nb4 as i32 + -3 * s.nb5 as i32 + 3 * s.nb0 as i32;
    m.ctx[5] = 11264 * ((t157 as i32) & 0xFC) + 5;
    let mut t159: i8 = -1;
    if t158 <= 255 {
        t159 = 0;
        if t158 >= 0 {
            t159 = (s.nb4 as i32 + -3 * s.nb5 as i32 + 3 * s.nb0 as i32) as i8;
        }
    }
    m.ctx[6] = 11264 * ((t159 as i32) & 0xFC) + 6;
    m.ctx[7] = 11264 * ((s.nb6 as i32 + s.nb7 as i32) >> 1) + 7;
    if ctx_need() <= 8 {
        m.nctx = 8;
        return;
    }
    let mut t160: u8 = -1i8 as u8;
    let t161: i32 = s.nb2 as i32 + s.nb53 as i32 - s.nb51 as i32;
    if t161 <= 255 {
        t160 = 0;
        if t161 >= 0 {
            t160 = (s.nb2 as i32 + s.nb53 as i32 - s.nb51 as i32) as u8;
        }
    }
    m.ctx[8] = 11264 * (t160 as i32) + 8;
    let t162: i32 = s.nb0 as i32 + s.nb53 as i32 - s.nb52 as i32;
    let mut t163: u8 = -1i8 as u8;
    if t162 <= 255 {
        t163 = 0;
        if t162 >= 0 {
            t163 = (s.nb0 as i32 + s.nb53 as i32 - s.nb52 as i32) as u8;
        }
    }
    m.ctx[9] = 11264 * (t163 as i32) + 9;
    let mut t164: i8 = -1;
    let t165: i32 = (3 * (s.nb2 as i32 + s.nb0 as i32) - 2 * s.nb3 as i32) / 4;
    if t165 <= 255 {
        t164 = 0;
        if t165 >= 0 {
            t164 = ((3 * (s.nb2 as i32 + s.nb0 as i32) - 2 * s.nb3 as i32) / 4) as i8;
        }
    }
    m.ctx[10] = 11264 * ((t164 as i32) & 0xFE) + 10;
    let mut t166: u8 = -1i8 as u8;
    if t155 <= 255 {
        t166 = 0;
        if t155 >= 0 {
            t166 = (2 * s.nb1 as i32 - s.nb14 as i32) as u8;
        }
    }
    let t167: i32 = 2 * s.nb34 as i32 - s.nb36 as i32;
    let mut t168: u8 = -1i8 as u8;
    if t167 <= 255 {
        t168 = 0;
        if t167 >= 0 {
            t168 = (2 * s.nb34 as i32 - s.nb36 as i32) as u8;
        }
    }
    let t169: i32 = (-10 * s.nb7 as i32 + 5 * s.nb12 as i32 - s.nb11 as i32
        + 10 * s.nb2 as i32
        + t166 as i32)
        / 5
        + s.nb33 as i32
        + (t168 as i32 + 10 * s.nb26 as i32 - 10 * s.nb28 as i32 + 5 * s.nb30 as i32
            - s.nb29 as i32)
            / -5;
    let mut t170: i8 = -1;
    if t169 <= 255 {
        t170 = 0;
        if t169 >= 0 {
            t170 = t169 as i8;
        }
    }
    m.ctx[11] = 11264 * ((t170 as i32) & 0xFE) + 11;
    if ctx_need() <= 12 {
        m.nctx = 12;
        return;
    }
    let t171: i32 = s.nb33 as i32
        + (t88 - s.nb3 as i32 + 6 * s.nb1 as i32 + s.nb18 as i32 - 4 * s.nb15 as i32) / 4
        - (2 * s.nb26 as i32 - s.nb32 as i32 + 6 * s.nb34 as i32 + s.nb49 as i32
            - 4 * s.nb39 as i32)
            / 4;
    let mut t172: i8 = -1;
    if t171 <= 255 {
        t172 = 0;
        if t171 >= 0 {
            t172 = (s.nb33 as i32
                + (t88 - s.nb3 as i32 + 6 * s.nb1 as i32 + s.nb18 as i32 - 4 * s.nb15 as i32) / 4
                - (2 * s.nb26 as i32 - s.nb32 as i32 + 6 * s.nb34 as i32 + s.nb49 as i32
                    - 4 * s.nb39 as i32)
                    / 4) as i8;
        }
    }
    m.ctx[12] = 11264 * ((t172 as i32) & 0xFE) + 12;
    let mut t173: u8 = -1i8 as u8;
    let t174: i32 = s.nb33 as i32 + s.nb6 as i32 + s.nb7 as i32 - s.nb0 as i32
        - (s.nb28 as i32 + s.nb35 as i32 - s.nb27 as i32);
    if t174 <= 255 {
        t173 = 0;
        if t174 >= 0 {
            t173 = (s.nb33 as i32 + s.nb6 as i32 + s.nb7 as i32 - s.nb0 as i32
                - (s.nb28 as i32 + s.nb35 as i32 - s.nb27 as i32)) as u8;
        }
    }
    m.ctx[13] = 11264 * (t173 as i32) + 13;
    let t175: i32 = s.nb53 as i32 + t150 - (s.nb52 as i32 + s.nb51 as i32 - s.nb54 as i32);
    let mut t176: i8 = -1;
    if t175 <= 255 {
        t176 = 0;
        if t175 >= 0 {
            t176 = (s.nb53 as i32 + t150 - (s.nb52 as i32 + s.nb51 as i32 - s.nb54 as i32)) as i8;
        }
    }
    let mut t177: i32 = (t176 as i32) & 0xFC;
    t177 |= 0x100;
    let mut t178: u8 = -1i8 as u8;
    let t179: i32 = -3 * s.nb7 as i32 + 8 * s.nb2 as i32;
    m.ctx[14] = 11264 * t177 + 14;
    let t180: i32 = 2 * s.nb6 as i32 - s.nb15 as i32;
    if t180 <= 255 {
        t178 = 0;
        if t180 >= 0 {
            t178 = (2 * s.nb6 as i32 - s.nb15 as i32) as u8;
        }
    }
    let t181: i32 = 2 * s.nb35 as i32 - s.nb39 as i32;
    let mut t182: u8 = -1i8 as u8;
    let t183: i32 = (t179 + t178 as i32) / 6 + s.nb33 as i32;
    if t181 <= 255 {
        t182 = 0;
        if t181 >= 0 {
            t182 = (2 * s.nb35 as i32 - s.nb39 as i32) as u8;
        }
    }
    let t184: i32 = t183 + (t182 as i32 + -3 * s.nb28 as i32 + 8 * s.nb26 as i32) / -6;
    let mut t185: i8 = -1;
    if t184 <= 255 {
        t185 = 0;
        if t184 >= 0 {
            t185 = t184 as i8;
        }
    }
    m.ctx[15] = 11264 * ((t185 as i32) & 0xFE) + 15;
    let mut t186: u8 = -1i8 as u8;
    let t187: i32 = -6 * s.nb14 as i32 + 4 * s.nb1 as i32 + 4 * s.nb10 as i32 - s.nb16 as i32;
    if t187 <= 255 {
        t186 = 0;
        if t187 >= 0 {
            t186 = (-6 * s.nb14 as i32 + 4 * s.nb1 as i32 + 4 * s.nb10 as i32 - s.nb16 as i32)
                as u8;
        }
    }
    let mut t188: i8 = -1;
    let t189: i32 = (t186 as i32 + s.nb12 as i32 - 4 * s.nb7 as i32 + 6 * s.nb2 as i32) / 4;
    if t189 <= 255 {
        t188 = 0;
        if t189 >= 0 {
            t188 =
                ((t186 as i32 + s.nb12 as i32 - 4 * s.nb7 as i32 + 6 * s.nb2 as i32) / 4) as i8;
        }
    }
    m.ctx[16] = 11264 * ((t188 as i32) & 0xFC) + 16;
    let mut t190: u8 = -1i8 as u8;
    let t191: i32 = t88 - s.nb8 as i32;
    if t191 <= 255 {
        t190 = 0;
        if t191 >= 0 {
            t190 = (t88 - s.nb8 as i32) as u8;
        }
    }
    let mut t192: u8 = -1i8 as u8;
    let t193: i32 = 2 * s.nb26 as i32 - s.nb31 as i32;
    if t193 <= 255 {
        t192 = 0;
        if t193 >= 0 {
            t192 = (2 * s.nb26 as i32 - s.nb31 as i32) as u8;
        }
    }
    let t194: i32 = (t190 as i32 + 15 * s.nb0 as i32 - 20 * s.nb5 as i32 + 15 * s.nb4 as i32
        + s.nb25 as i32
        - 6 * s.nb22 as i32)
        / 6
        + s.nb33 as i32
        + (t192 as i32 + 15 * s.nb27 as i32 - 20 * s.nb42 as i32 + 15 * s.nb47 as i32
            + s.nb57 as i32
            - 6 * s.nb55 as i32)
            / -6;
    let mut t195: i8 = -1;
    if t194 <= 255 {
        t195 = 0;
        if t194 >= 0 {
            t195 = ((t190 as i32 + 15 * s.nb0 as i32 - 20 * s.nb5 as i32 + 15 * s.nb4 as i32
                + s.nb25 as i32
                - 6 * s.nb22 as i32)
                / 6
                + s.nb33 as i32
                + (t192 as i32 + 15 * s.nb27 as i32 - 20 * s.nb42 as i32 + 15 * s.nb47 as i32
                    + s.nb57 as i32
                    - 6 * s.nb55 as i32)
                    / -6) as i8;
        }
    }
    m.ctx[17] = 11264 * ((t195 as i32) & 0xFC) + 17;
    let mut t196: u8 = -1i8 as u8;
    let t197: i32 = s.nb33 as i32 + s.nb0 as i32 + s.nb12 as i32 - s.nb21 as i32
        - (s.nb27 as i32 + s.nb30 as i32 - s.nb41 as i32);
    if t197 <= 255 {
        t196 = 0;
        if t197 >= 0 {
            t196 = (s.nb33 as i32 + s.nb0 as i32 + s.nb12 as i32 - s.nb21 as i32
                - (s.nb27 as i32 + s.nb30 as i32 - s.nb41 as i32)) as u8;
        }
    }
    m.ctx[18] = 11264 * (t196 as i32) + 18;
    m.ctx[19] = 11264 * ((s.nb50 as i32) & 0xFC) + 19;
    m.ctx[20] = 11264 * ((s.nb53 as i32) | 1) + 20;
    let mut t198: u8 = -1i8 as u8;
    let t199: i32 = s.nb33 as i32 + s.nb13 as i32 - s.nb37 as i32;
    m.ctx[21] = 11264 * ((s.nb38 as i32) & 0xFC) + 21;
    if t199 <= 255 {
        t198 = 0;
        if t199 >= 0 {
            t198 = (s.nb33 as i32 + s.nb13 as i32 - s.nb37 as i32) as u8;
        }
    }
    m.ctx[23] = 11264 * s.nb33 as i32 + 23;
    m.ctx[22] = 11264 * (t198 as i32) + 22;
    m.ctx[24] = 11264 * (((s.nb2 as i32) >> 1) | ((16 * s.nb7 as i32) & 0xF80)) + 24;
    m.ctx[25] = 11264 * (((s.nb0 as i32) >> 1) | ((16 * s.nb5 as i32) & 0xF80)) + 25;
    m.ctx[26] = 11264 * (((s.nb33 as i32) >> 1) | ((16 * s.nb53 as i32) & 0xF80)) + 26;
    let mut t200: i8 = -1;
    let t201: i32 = s.nb33 as i32 + s.nb3 as i32 - s.nb32 as i32;
    m.ctx[27] = 11264 * (((s.nb2 as i32) >> 2) | ((16 * s.nb12 as i32) & 0xFC0)) + 27;
    if t201 <= 255 {
        t200 = 0;
        if t201 >= 0 {
            t200 = (s.nb33 as i32 + s.nb3 as i32 - s.nb32 as i32) as i8;
        }
    }
    let mut t202: i8 = -1;
    let t203: i32 = 11264 * ((t78 >> 5) | ((t200 as i32) & 0xFE));
    let t204: i32 = s.nb1 as i32 + s.nb33 as i32 - s.nb34 as i32;
    m.ctx[28] = t203 + 28;
    if t204 <= 255 {
        t202 = 0;
        if t204 >= 0 {
            t202 = (s.nb1 as i32 + s.nb33 as i32 - s.nb34 as i32) as i8;
        }
    }
    let t205: i32 = s.nb33 as i32 + s.nb8 as i32 - s.nb31 as i32;
    let mut t206: i8 = -1;
    m.ctx[29] = 11264 * ((t78 >> 3) | ((t202 as i32) & 0xF8)) + 29;
    m.ctx[30] = 11264
        * (((s.nb2 as i32) >> 4) | ((s.nb0 as i32) & 0xF0) | ((16 * s.nb33 as i32) & 0xF00))
        + 30;
    if t205 <= 255 {
        t206 = 0;
        if t205 >= 0 {
            t206 = (s.nb33 as i32 + s.nb8 as i32 - s.nb31 as i32) as i8;
        }
    }
    let mut t207: i8 = -1;
    let t208: i32 = s.nb33 as i32 + s.nb23 as i32 - s.nb40 as i32;
    m.ctx[31] = 11264 * ((t206 as i32) & 0xFE) + 31;
    if t208 <= 255 {
        t207 = 0;
        if t208 >= 0 {
            t207 = (s.nb33 as i32 + s.nb23 as i32 - s.nb40 as i32) as i8;
        }
    }
    let mut t209: i32 = 1;
    m.ctx[32] = 11264 * ((t207 as i32) & 0xFE) + 32;
    m.ctx[33] = 11264 * ((s.nb9 as i32) & 0xFE) + 33;
    m.ctx[34] = 11264 * ((s.nb51 as i32) & 0xFC) + 34;
    m.ctx[35] = 11264 * ((s.nb52 as i32) & 0xFC) + 35;
    let mut t210: i32 = s.nb27 as i32;
    let mut t211: i8 = -1;
    if s.nb27 == 0 {
        t210 = 1;
    }
    let mut t212: i32 = s.nb33 as i32 * s.nb0 as i32 / t210;
    if t212 > 255 {
        t212 = 255;
    }
    let t213: i32 = 11264 * ((t212 as i32) & 0xFE);
    if s.nb26 == 0 {
        t144 = 1;
    }
    let mut t214: i32 = s.nb33 as i32 * s.nb2 as i32 / t144;
    if t214 > 255 {
        t214 = 255;
    }
    if s.nb34 != 0 {
        t209 = s.nb34 as i32;
    }
    if s.nb1 as i32 * s.nb33 as i32 / t209 <= 255 {
        t211 = (s.nb1 as i32 * s.nb33 as i32 / t209) as i8;
    }
    let t215: i32 = s.nb1 as i32 + s.nb33 as i32 - s.nb38 as i32;
    m.ctx[36] = 11264 * ((s.nb4 as i32) & 0xFE) + 36;
    m.ctx[37] = t213 + 37;
    m.ctx[38] = 11264 * ((t214 as i32) & 0xFE) + 38;
    m.ctx[39] = 11264 * ((t211 as i32) & 0xFE) + 39;
    let mut t216: i8 = -1;
    if t215 <= 255 {
        t216 = 0;
        if t215 >= 0 {
            t216 = (s.nb1 as i32 + s.nb33 as i32 - s.nb38 as i32) as i8;
        }
    }
    let mut t217: i8 = -1;
    m.ctx[40] = 11264 * ((t216 as i32) & 0xFE) + 40;
    if t150 <= 255 {
        t217 = 0;
        if t150 >= 0 {
            t217 = (s.nb2 as i32 + s.nb0 as i32 - s.nb3 as i32) as i8;
        }
    }
    let mut t218: u8 = -1i8 as u8;
    m.ctx[41] = 11264 * ((t217 as i32) & 0xFE) + 41;
    if t180 <= 255 {
        t218 = 0;
        if t180 >= 0 {
            t218 = (2 * s.nb6 as i32 - s.nb15 as i32) as u8;
        }
    }
    let mut t219: i8 = -1;
    let t220: i32 = (t179 + t218 as i32) / 6;
    if t220 <= 255 {
        t219 = 0;
        if t220 >= 0 {
            t219 = t220 as i8;
        }
    }
    let mut t221: i8 = -1;
    m.ctx[42] = 11264 * ((t219 as i32) & 0xFE) + 42;
    let t222: i32 = s.nb1 as i32 + s.nb53 as i32 - s.nb56 as i32;
    if t222 <= 255 {
        t221 = 0;
        if t222 >= 0 {
            t221 = (s.nb1 as i32 + s.nb53 as i32 - s.nb56 as i32) as i8;
        }
    }
    m.nctx = 44;
    s.nb51 = s.nb53;
    m.ctx[43] = 11264 * ((t221 as i32) & 0xFE) + 43;
    s.nb54 = s.nb52;
    s.nb52 = s.nb56;
}

pub fn ctx_blue(m: &mut DmModel, s: &mut Frame, buf: &[u8]) {
    load_neighbours(s, buf);

    m.nctx = 0;
    m.c0 = 1;
    m.bitpos = 0;
    let t78: i32 = ((s.x << 6) / s.w) as u8 as i32;
    let t86: i32 = s.nb2 as i32 + s.nb1 as i32;
    let t79: i32 = (if s.nb3 < s.nb0 { 0x10 } else { 0 })
        | (8 * ((abs32(s.nb0 as i32 - s.nb3 as i32) >= 4) as i32))
        | (if s.nb3 < s.nb2 { 4 } else { 0 })
        | ((abs32(s.nb2 as i32 - s.nb0 as i32) > 3) as i32)
        | (if s.nb0 < s.nb2 { 2 } else { 0 });
    let mut t82: i32 = 0;
    let mut t80: i32 = 32;
    if abs32(s.nb0 as i32 - s.nb1 as i32) < 9 {
        t80 = 0;
    }
    let t81: i32 = (if s.nb1 < s.nb0 { 0x40 } else { 0 }) | t80 | t79;
    if abs32(s.nb2 as i32 - s.nb7 as i32) > abs32(s.nb0 as i32 - s.nb5 as i32) {
        t82 = 128;
    }
    let t83: i32 = ((t81 | t82) << 12)
        | (((s.nb2 as i32 + s.nb1 as i32) >> 1) & 0xC0)
        | t78
        | (((s.y16 / s.h) as u8 as i32) << 8);
    let t88: i32 = 2 * s.nb2 as i32;
    m.ctx48 = t83;

    if s.h <= s.y_next {
        s.nb44 = 0;
    } else {
        s.nb44 = Frame::sample(buf, s.px_off + s.stride + 1);
    }
    if s.w <= s.x_next {
        s.nb38 = 0;
    } else {
        s.nb38 = Frame::sample(buf, s.px_off + 4);
    }
    if s.y_scan != 0 {
        if s.w <= s.x + 4 {
            s.nb43 = 0;
        } else {
            s.nb43 = Frame::sample(buf, s.px_off - s.stride + 13);
        }
        if s.y_scan <= 1 {
            s.nb46 = 0;
            s.nb48 = 0;
            s.nb39 = 0;
            s.nb45 = 0;
        } else {
            if s.w <= s.x + 2 {
                s.nb39 = 0;
            } else {
                s.nb39 = Frame::sample(buf, s.px_off + 7 - 2 * s.stride);
            }
            if s.y_scan == 2 {
                s.nb46 = 0;
                s.nb48 = 0;
                s.nb45 = 0;
            } else {
                s.nb48 = Frame::sample(buf, s.px_off + 1 - 3 * s.stride);
                if s.y_scan == 3 {
                    s.nb46 = 0;
                    s.nb45 = 0;
                } else {
                    s.nb46 = Frame::sample(buf, s.px_off + 1 - 4 * s.stride);
                    if s.y_scan == 4 {
                        s.nb45 = 0;
                    } else {
                        s.nb45 = Frame::sample(buf, s.px_off + 1 - 5 * s.stride);
                    }
                }
            }
        }
    } else {
        s.nb46 = 0;
        s.nb48 = 0;
        s.nb39 = 0;
        s.nb43 = 0;
        s.nb45 = 0;
    }

    let mut t223: u8 = -1i8 as u8;
    let mut t224: i32 = s.nb26 as i32;
    let t225: i32 = s.nb2 as i32 + s.nb33 as i32 - s.nb26 as i32;
    if t225 <= 255 {
        t223 = 0;
        if t225 >= 0 {
            t223 = (s.nb2 as i32 + s.nb33 as i32 - s.nb26 as i32) as u8;
        }
    }
    let t226: i32 = t223 as i32;
    let mut t227: u8 = -1i8 as u8;
    let t228: i32 = s.nb0 as i32 + s.nb33 as i32 - s.nb27 as i32;
    m.ctx[0] = 11264 * t226;
    if t228 <= 255 {
        t227 = 0;
        if t228 >= 0 {
            t227 = (s.nb0 as i32 + s.nb33 as i32 - s.nb27 as i32) as u8;
        }
    }
    let mut t229: i8 = -1;
    let t230: i32 = s.nb2 as i32 + s.nb0 as i32 - s.nb3 as i32;
    let t231: i32 = s.nb33 as i32 + t230 - (s.nb26 as i32 + s.nb27 as i32 - s.nb32 as i32);
    m.ctx[1] = 11264 * (t227 as i32) + 1;
    if t231 <= 255 {
        t229 = 0;
        if t231 >= 0 {
            t229 = (s.nb33 as i32 + t230 - (s.nb26 as i32 + s.nb27 as i32 - s.nb32 as i32)) as i8;
        }
    }
    let mut t232: u8 = -1i8 as u8;
    m.ctx[2] = 11264
        * (((s.nb17 as i32 + s.nb0 as i32 - s.nb5 as i32 - s.nb3 as i32) as u8 as i32) >> 7
            | ((t229 as i32) & 0xFE))
        + 2;
    let t233: i32 = s.nb33 as i32 + t86 - s.nb0 as i32
        - (s.nb26 as i32 + s.nb34 as i32 - s.nb27 as i32);
    if t233 <= 255 {
        t232 = 0;
        if t233 >= 0 {
            t232 = t233 as u8;
        }
    }
    let mut t234: u8 = -1i8 as u8;
    let t235: i32 = 2 * s.nb1 as i32 - s.nb14 as i32;
    m.ctx[3] = 11264 * (t232 as i32) + 3;
    if t235 <= 255 {
        t234 = 0;
        if t235 >= 0 {
            t234 = (2 * s.nb1 as i32 - s.nb14 as i32) as u8;
        }
    }
    m.ctx[4] = 11264 * ((s.nb2 as i32 + t234 as i32) >> 1) + 4;
    let mut t236: i8 = -1;
    let t237: i32 = s.nb12 as i32 + -3 * s.nb7 as i32 + 3 * s.nb2 as i32;
    if t237 <= 255 {
        t236 = 0;
        if t237 >= 0 {
            t236 = (s.nb12 as i32 + -3 * s.nb7 as i32 + 3 * s.nb2 as i32) as i8;
        }
    }
    m.ctx[5] = 11264 * ((t236 as i32) & 0xFC) + 5;
    let mut t238: i8 = -1;
    let t239: i32 = s.nb4 as i32 + -3 * s.nb5 as i32 + 3 * s.nb0 as i32;
    if t239 <= 255 {
        t238 = 0;
        if t239 >= 0 {
            t238 = (s.nb4 as i32 + -3 * s.nb5 as i32 + 3 * s.nb0 as i32) as i8;
        }
    }
    m.ctx[6] = 11264 * ((t238 as i32) & 0xFC) + 6;
    m.ctx[8] = 11264 * s.nb2 as i32 + 8;
    m.ctx[7] = 11264 * ((s.nb6 as i32 + s.nb7 as i32) >> 1) + 7;
    if ctx_need() <= 8 {
        m.nctx = 8;
        return;
    }
    m.ctx[9] = 11264 * s.nb0 as i32 + 9;
    let mut t240: i8 = -1;
    let t241: i32 = (3 * (s.nb2 as i32 + s.nb0 as i32) - 2 * s.nb3 as i32) / 4;
    if t241 <= 255 {
        t240 = 0;
        if t241 >= 0 {
            t240 = ((3 * (s.nb2 as i32 + s.nb0 as i32) - 2 * s.nb3 as i32) / 4) as i8;
        }
    }
    m.ctx[10] = 11264 * ((t240 as i32) & 0xFE) + 10;
    let mut t242: u8 = -1i8 as u8;
    if t235 <= 255 {
        t242 = 0;
        if t235 >= 0 {
            t242 = (2 * s.nb1 as i32 - s.nb14 as i32) as u8;
        }
    }
    let t243: i32 = 2 * s.nb34 as i32 - s.nb36 as i32;
    let mut t244: u8 = -1i8 as u8;
    if t243 <= 255 {
        t244 = 0;
        if t243 >= 0 {
            t244 = (2 * s.nb34 as i32 - s.nb36 as i32) as u8;
        }
    }
    let t245: i32 = (-10 * s.nb7 as i32 + 5 * s.nb12 as i32 - s.nb11 as i32
        + 10 * s.nb2 as i32
        + t242 as i32)
        / 5
        + s.nb33 as i32
        + (t244 as i32 + 10 * s.nb26 as i32 - 10 * s.nb28 as i32 + 5 * s.nb30 as i32
            - s.nb29 as i32)
            / -5;
    let mut t246: i8 = -1;
    if t245 <= 255 {
        t246 = 0;
        if t245 >= 0 {
            t246 = t245 as i8;
        }
    }
    m.ctx[11] = 11264 * ((t246 as i32) & 0xFE) + 11;
    if ctx_need() <= 12 {
        m.nctx = 12;
        return;
    }
    let t247: i32 = (6 * s.nb1 as i32 + s.nb18 as i32 - 4 * s.nb15 as i32 - 6 * s.nb3 as i32
        + 4 * s.nb2 as i32
        + 4 * s.nb17 as i32
        - s.nb24 as i32)
        / 4;
    let mut t248: i8 = -1;
    if t247 <= 255 {
        t248 = 0;
        if t247 >= 0 {
            t248 = ((6 * s.nb1 as i32 + s.nb18 as i32 - 4 * s.nb15 as i32 - 6 * s.nb3 as i32
                + 4 * s.nb2 as i32
                + 4 * s.nb17 as i32
                - s.nb24 as i32)
                / 4) as i8;
        }
    }
    m.ctx[12] = 11264 * ((t248 as i32) & 0xFE) + 12;
    let mut t249: u8 = -1i8 as u8;
    let t250: i32 = s.nb33 as i32 + s.nb6 as i32 + s.nb7 as i32 - s.nb0 as i32
        - (s.nb28 as i32 + s.nb35 as i32 - s.nb27 as i32);
    if t250 <= 255 {
        t249 = 0;
        if t250 >= 0 {
            t249 = (s.nb33 as i32 + s.nb6 as i32 + s.nb7 as i32 - s.nb0 as i32
                - (s.nb28 as i32 + s.nb35 as i32 - s.nb27 as i32)) as u8;
        }
    }
    m.ctx[13] = 11264 * (t249 as i32) + 13;
    let mut t251: u8 = -1i8 as u8;
    let t252: i32 = s.nb5 as i32 + s.nb33 as i32 - s.nb42 as i32;
    if t252 <= 255 {
        t251 = 0;
        if t252 >= 0 {
            t251 = (s.nb5 as i32 + s.nb33 as i32 - s.nb42 as i32) as u8;
        }
    }
    m.ctx[14] = 11264 * (t251 as i32) + 14;
    let t253: i32 = -3 * s.nb7 as i32 + 8 * s.nb2 as i32;
    let mut t254: u8 = -1i8 as u8;
    let t255: i32 = 2 * s.nb6 as i32 - s.nb15 as i32;
    if t255 <= 255 {
        t254 = 0;
        if t255 >= 0 {
            t254 = (2 * s.nb6 as i32 - s.nb15 as i32) as u8;
        }
    }
    let t256: i32 = 2 * s.nb35 as i32 - s.nb39 as i32;
    let mut t257: u8 = -1i8 as u8;
    if t256 <= 255 {
        t257 = 0;
        if t256 >= 0 {
            t257 = (2 * s.nb35 as i32 - s.nb39 as i32) as u8;
        }
    }
    let t258: i32 = (t253 + t254 as i32) / 6 + s.nb33 as i32
        + (t257 as i32 + -3 * s.nb28 as i32 + 8 * s.nb26 as i32) / -6;
    let mut t259: i8 = -1;
    if t258 <= 255 {
        t259 = 0;
        if t258 >= 0 {
            t259 = t258 as i8;
        }
    }
    m.ctx[15] = 11264 * ((t259 as i32) & 0xFE) + 15;
    let mut t260: u8 = -1i8 as u8;
    let t261: i32 = -6 * s.nb14 as i32 + 4 * s.nb1 as i32 + 4 * s.nb10 as i32 - s.nb16 as i32;
    if t261 <= 255 {
        t260 = 0;
        if t261 >= 0 {
            t260 = (-6 * s.nb14 as i32 + 4 * s.nb1 as i32 + 4 * s.nb10 as i32 - s.nb16 as i32)
                as u8;
        }
    }
    let t262: i32 = t260 as i32 + s.nb12 as i32 - 4 * s.nb7 as i32 + 6 * s.nb2 as i32;
    let mut t263: i8 = -1;
    let t264: i32 = t262 / 4;
    if t264 <= 255 {
        t263 = 0;
        if t264 >= 0 {
            t263 = t264 as i8;
        }
    }
    m.ctx[16] = 11264 * ((t263 as i32) & 0xFC) + 16;
    let mut t265: u8 = -1i8 as u8;
    let t266: i32 = t88 - s.nb8 as i32;
    if t266 <= 255 {
        t265 = 0;
        if t266 >= 0 {
            t265 = (t88 - s.nb8 as i32) as u8;
        }
    }
    let t267: i32 = (t265 as i32 + 15 * s.nb0 as i32 - 20 * s.nb5 as i32 + 15 * s.nb4 as i32
        + s.nb25 as i32
        - 6 * s.nb22 as i32)
        / 6
        + s.nb33 as i32;
    let mut t268: u8 = -1i8 as u8;
    let t269: i32 = 2 * s.nb26 as i32 - s.nb31 as i32;
    if t269 <= 255 {
        t268 = 0;
        if t269 >= 0 {
            t268 = (2 * s.nb26 as i32 - s.nb31 as i32) as u8;
        }
    }
    let t270: i32 = t267
        + (t268 as i32 + 15 * s.nb27 as i32 - 20 * s.nb42 as i32 + 15 * s.nb48 as i32
            + s.nb45 as i32
            - 6 * s.nb46 as i32)
            / -6;
    let mut t271: i8 = -1;
    if t270 <= 255 {
        t271 = 0;
        if t270 >= 0 {
            t271 = t270 as i8;
        }
    }
    m.ctx[17] = 11264 * ((t271 as i32) & 0xFC) + 17;
    let mut t272: u8 = -1i8 as u8;
    let t273: i32 = s.nb33 as i32 + s.nb0 as i32 + s.nb12 as i32 - s.nb21 as i32
        - (s.nb27 as i32 + s.nb30 as i32 - s.nb41 as i32);
    if t273 <= 255 {
        t272 = 0;
        if t273 >= 0 {
            t272 = (s.nb33 as i32 + s.nb0 as i32 + s.nb12 as i32 - s.nb21 as i32
                - (s.nb27 as i32 + s.nb30 as i32 - s.nb41 as i32)) as u8;
        }
    }
    m.ctx[18] = 11264 * (t272 as i32) + 18;
    let mut t274: i8 = -1;
    m.ctx[19] = 11264 * ((s.nb44 as i32) & 0xFC) + 19;
    let t275: i32 = s.nb2 as i32 + s.nb38 as i32 - s.nb33 as i32;
    if t275 <= 255 {
        t274 = 0;
        if t275 >= 0 {
            t274 = (s.nb2 as i32 + s.nb38 as i32 - s.nb33 as i32) as i8;
        }
    }
    m.ctx[20] = 11264 * ((t274 as i32) & 0xFE) + 20;
    m.ctx[21] = 11264 * ((s.nb38 as i32) & 0xFC) + 21;
    let mut t276: u8 = -1i8 as u8;
    let t277: i32 = s.nb33 as i32 + s.nb13 as i32 - s.nb37 as i32;
    if t277 <= 255 {
        t276 = 0;
        if t277 >= 0 {
            t276 = (s.nb33 as i32 + s.nb13 as i32 - s.nb37 as i32) as u8;
        }
    }
    let mut t278: i8 = -1;
    let t279: i32 = 11264 * (t276 as i32) + 22;
    let t280: i32 = s.nb0 as i32 + s.nb44 as i32 - s.nb33 as i32;
    m.ctx[22] = t279;
    if t280 <= 255 {
        t278 = 0;
        if t280 >= 0 {
            t278 = (s.nb0 as i32 + s.nb44 as i32 - s.nb33 as i32) as i8;
        }
    }
    m.ctx[23] = 11264 * ((t278 as i32) & 0xFE) + 23;
    m.ctx[24] = 11264 * (((s.nb2 as i32) >> 1) | ((16 * s.nb7 as i32) & 0xF80)) + 24;
    m.ctx[25] = 11264 * (((s.nb0 as i32) >> 1) | ((16 * s.nb5 as i32) & 0xF80)) + 25;
    m.ctx[26] = 11264 * s.nb33 as i32 + 26;
    let t281: i32 = s.nb33 as i32 + s.nb3 as i32 - s.nb32 as i32;
    m.ctx[27] = 11264 * (((s.nb2 as i32) >> 2) | ((16 * s.nb12 as i32) & 0xFC0)) + 27;
    let mut t282: i8 = -1;
    if t281 <= 255 {
        t282 = 0;
        if t281 >= 0 {
            t282 = (s.nb33 as i32 + s.nb3 as i32 - s.nb32 as i32) as i8;
        }
    }
    let t283: i32 = 11264 * ((t78 >> 5) | ((t282 as i32) & 0xFE));
    let mut t284: i8 = -1;
    m.ctx[28] = t283 + 28;
    let t285: i32 = s.nb1 as i32 + s.nb33 as i32 - s.nb34 as i32;
    if t285 <= 255 {
        t284 = 0;
        if t285 >= 0 {
            t284 = (s.nb1 as i32 + s.nb33 as i32 - s.nb34 as i32) as i8;
        }
    }
    let t286: i32 = s.nb33 as i32 + s.nb8 as i32 - s.nb31 as i32;
    let mut t287: i8 = -1;
    m.ctx[29] = 11264 * ((t78 >> 3) | ((t284 as i32) & 0xF8)) + 29;
    m.ctx[30] = 11264
        * (((s.nb2 as i32) >> 4) | ((s.nb0 as i32) & 0xF0) | ((16 * s.nb33 as i32) & 0xF00))
        + 30;
    if t286 <= 255 {
        t287 = 0;
        if t286 >= 0 {
            t287 = (s.nb33 as i32 + s.nb8 as i32 - s.nb31 as i32) as i8;
        }
    }
    let t288: i32 = 11264 * ((t287 as i32) & 0xFE);
    let mut t289: i8 = -1;
    let t290: i32 = s.nb33 as i32 + s.nb23 as i32 - s.nb40 as i32;
    m.ctx[31] = t288 + 31;
    if t290 <= 255 {
        t289 = 0;
        if t290 >= 0 {
            t289 = (s.nb33 as i32 + s.nb23 as i32 - s.nb40 as i32) as i8;
        }
    }
    let mut t291: i32 = 1;
    m.ctx[32] = 11264 * ((t289 as i32) & 0xFE) + 32;
    m.ctx[33] = 11264 * ((s.nb9 as i32) & 0xFE) + 33;
    m.ctx[34] = 11264 * ((s.nb26 as i32) & 0xFC) + 34;
    m.ctx[35] = 11264 * ((s.nb27 as i32) & 0xFC) + 35;
    let mut t292: i32 = s.nb27 as i32;
    let mut t293: i8 = -1;
    if s.nb27 == 0 {
        t292 = 1;
    }
    let mut t294: i32 = s.nb33 as i32 * s.nb0 as i32 / t292;
    if t294 > 255 {
        t294 = 255;
    }
    if s.nb26 == 0 {
        t224 = 1;
    }
    let mut t295: i32 = s.nb33 as i32 * s.nb2 as i32 / t224;
    if t295 > 255 {
        t295 = 255;
    }
    if s.nb34 != 0 {
        t291 = s.nb34 as i32;
    }
    if s.nb33 as i32 * s.nb1 as i32 / t291 <= 255 {
        t293 = (s.nb33 as i32 * s.nb1 as i32 / t291) as i8;
    }
    let t296: i32 = s.nb1 as i32 + s.nb33 as i32 - s.nb38 as i32;
    let mut t297: i8 = -1;
    m.ctx[36] = 11264 * ((s.nb4 as i32) & 0xFE) + 36;
    m.ctx[37] = 11264 * ((t294 as i32) & 0xFE) + 37;
    m.ctx[38] = 11264 * ((t295 as i32) & 0xFE) + 38;
    m.ctx[39] = 11264 * ((t293 as i32) & 0xFE) + 39;
    if t296 <= 255 {
        t297 = 0;
        if t296 >= 0 {
            t297 = (s.nb1 as i32 + s.nb33 as i32 - s.nb38 as i32) as i8;
        }
    }
    let mut t298: i8 = -1;
    m.ctx[40] = 11264 * ((t297 as i32) & 0xFE) + 40;
    if t230 <= 255 {
        t298 = 0;
        if t230 >= 0 {
            t298 = (s.nb2 as i32 + s.nb0 as i32 - s.nb3 as i32) as i8;
        }
    }
    let mut t299: u8 = -1i8 as u8;
    m.ctx[41] = 11264 * ((t298 as i32) & 0xFE) + 41;
    if t255 <= 255 {
        t299 = 0;
        if t255 >= 0 {
            t299 = (2 * s.nb6 as i32 - s.nb15 as i32) as u8;
        }
    }
    let mut t300: i8 = -1;
    let t301: i32 = (t253 + t299 as i32) / 6;
    if t301 <= 255 {
        t300 = 0;
        if t301 >= 0 {
            t300 = t301 as i8;
        }
    }
    m.nctx = 44;
    m.ctx[42] = 11264 * ((t300 as i32) & 0xFE) + 42;
    m.ctx[43] = 11264 * ((s.nb28 as i32) | 1) + 43;
}
