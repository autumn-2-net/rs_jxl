//! Round 3: deepmix's context derivation driven by our full-tree model.
//!
//! The neighbour bank and the 37/44 context formulas are adapted from the
//! public-domain deepmix reference; the counter layout, mixer, APM stages and
//! priors are ours.

use crate::cm4::{BitCoder, Cm, NCTX};
use crate::dmctx::{
    advance_pixel, begin_row, begin_sample, ctx_blue, ctx_green, ctx_red, load_neighbours,
    next_plane, DmModel, Frame,
};
use crate::rc;
use crate::Codec;
use std::sync::OnceLock;

const MAGIC: &[u8; 4] = b"AC14";
fn kinds() -> [u8; NCTX] {
    static K: OnceLock<[u8; NCTX]> = OnceLock::new();
    *K.get_or_init(|| {
        let mut k = [1u8; NCTX];
        if let Ok(v) = std::env::var("R4_PRIOR_CTX") {
            if let Ok(n) = v.parse::<usize>() {
                for (i, x) in k.iter_mut().enumerate() {
                    if i >= n {
                        *x = 0;
                    }
                }
            }
        }
        k
    })
}

struct Tune {
    lr: i32,
    dm_rates: bool,
    rhi: u32,
    rlo: u32,
}

fn tune() -> &'static Tune {
    static T: OnceLock<Tune> = OnceLock::new();
    T.get_or_init(|| {
        let get = |k: &str, d: i64| {
            std::env::var(k).ok().and_then(|v| v.parse().ok()).unwrap_or(d)
        };
        Tune {
            lr: get("R4_LR", 3) as i32,
            dm_rates: get("R4_DMRATES", 1) != 0,
            rhi: get("R4_RHI", 2) as u32,
            rlo: get("R4_RLO", 3) as u32,
        }
    })
}

/// Deepmix's per-bit counter adaptation shifts for row `y`.
fn fast_ctx() -> bool {
    static F: OnceLock<bool> = OnceLock::new();
    *F.get_or_init(|| std::env::var("ACM_NODM").ok().as_deref() == Some("1"))
}

fn sel2() -> usize {
    static S: OnceLock<usize> = OnceLock::new();
    *S.get_or_init(|| {
        std::env::var("ACM_SEL2").ok().and_then(|v| v.parse().ok()).unwrap_or(1).min(6)
    })
}

#[inline(always)]
fn mix_sel_one(i: usize, c0: usize, bp: i32, u48: u32, hist: usize, m: i32) -> usize {
    let ctx48 = u48 as i32;
    ((match i {
        0 => c0 as i32 & m,
        1 => 256 + (bp | ((2 * ctx48) & 0x78)),
        2 => 384 + (c0 as i32 | (((ctx48 as u16 as i32) << 6) & 0xF00)),
        3 => 4480 + (((ctx48 & 0x20 != 0) as i32) | ((u48 >> 11) & 0x1FE) as i32),
        4 => 4992 + ((u48 >> 8) & 0xF) as i32 + ((u48 >> 2) & 0xF) as i32,
        5 => 5024 + (ctx48 as u8 as i32),
        _ => 5280 + (((c0 as i32) << bp) | (hist as i32 & ((1 << bp) - 1))),
    }) & m) as usize
}

fn sel_mode() -> i32 {
    static S: OnceLock<i32> = OnceLock::new();
    *S.get_or_init(|| std::env::var("R4_SEL").ok().and_then(|v| v.parse().ok()).unwrap_or(1))
}

fn apm_on() -> bool {
    static A: OnceLock<bool> = OnceLock::new();
    *A.get_or_init(|| std::env::var("R4_APM").map(|v| v != "0").unwrap_or(false))
}

fn apm_planes() -> [bool; 3] {
    static P: OnceLock<[bool; 3]> = OnceLock::new();
    *P.get_or_init(|| {
        let mut a = [false; 3];
        if let Ok(v) = std::env::var("ACM_APM_PLANE") {
            for (i, p) in v.split(',').take(3).enumerate() {
                a[i] = p != "0";
            }
        }
        a
    })
}

fn plane_mix() -> [usize; 3] {
    static P: OnceLock<[usize; 3]> = OnceLock::new();
    *P.get_or_init(|| {
        let base = std::env::var("ACM_MIX")
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .unwrap_or(crate::cm4::N_MIX1)
            .clamp(1, crate::cm4::N_MIX1);
        let mut a = [base; 3];
        if let Ok(v) = std::env::var("ACM_MIX_PLANE") {
            for (i, p) in v.split(',').take(3).enumerate() {
                a[i] = p.parse::<usize>().unwrap_or(crate::cm4::N_MIX1).clamp(1, crate::cm4::N_MIX1);
            }
        }
        a
    })
}

fn plane_nctx(_ch: usize) -> usize {
    static P: OnceLock<[usize; 3]> = OnceLock::new();
    let a = *P.get_or_init(|| {
        let mut a = [NCTX; 3];
        if let Ok(v) = std::env::var("ACM_NCTX_PLANE") {
            for (i, p) in v.split(',').take(3).enumerate() {
                a[i] = p.parse::<usize>().unwrap_or(NCTX).clamp(1, NCTX);
            }
        }
        a
    });
    a[_ch]
}

fn dm_rates(y: i64) -> [u32; 8] {
    let q50 = (y > 0x50) as u32;
    let qa0 = (y > 0xA0) as u32;
    let q10 = (y > 0x10) as u32;
    let q20 = (y > 0x20) as u32;
    let qf0 = (y > 0xF0) as u32;
    let q30 = (y > 0x30) as u32;
    let q100 = (y > 0x100) as u32;
    let q8 = (y > 8) as u32;
    let q80 = (y > 0x80) as u32;
    let q280 = (y > 0x280) as u32;
    let (s7, s6, s5, t307, t308);
    if y <= 8 {
        s7 = q50 + 5;
        s6 = qa0 + q10 + if y > 4 { 5 } else { 4 };
        s5 = q20 + qf0 + 4;
        t307 = 4;
        t308 = 5 - ((y < 5) as u32);
    } else {
        s7 = q50 + 6;
        s6 = qa0 + q10 + 5;
        s5 = q20 + qf0 + 5;
        t308 = 5;
        t307 = 5 - ((y < 5) as u32);
    }
    let s4 = q30 + t307 + q100;
    let s3 = t308 + q20 + q100;
    let s2 = q8 + q80 + if y <= 2 { 4 } else { 5 };
    let t309 = if y <= 2 {
        5
    } else {
        6 - ((y < 5) as u32)
    };
    let s1 = t309 + q30 + q280;
    let s0 = t309 + q50;
    [s7, s6, s5, s4, s3, s2, s1, s0]
}

const MATCH_BITS: usize = 18;

static RECIP: [u32; 256] = build_recip();

const fn build_recip() -> [u32; 256] {
    let mut r = [0u32; 256];
    let mut i = 1;
    while i < 256 {
        r[i] = ((65536 + i as u32 / 2) / i as u32) as u32;
        i += 1;
    }
    r
}

fn clamp255(v: i32) -> i32 {
    v.clamp(0, 255)
}

/// Anti-aliased edge predictor: the green channel says where inside the edge
/// the pixel sits; the same fraction interpolates the target channel.
fn alpha_pred(g: i32, gs: [i32; 4], cs: [i32; 4]) -> i32 {
    let mut imin = 0usize;
    let mut imax = 0usize;
    for i in 1..4 {
        if gs[i] < gs[imin] {
            imin = i;
        }
        if gs[i] > gs[imax] {
            imax = i;
        }
    }
    let denom = gs[imax] - gs[imin];
    if denom <= 0 {
        return cs[0];
    }
    let num = (g - gs[imin]).clamp(0, denom) as u32;
    let alpha = (num * RECIP[denom as usize]) >> 8;
    let a = cs[imin];
    let b = cs[imax];
    clamp255(a + ((alpha as i32 * (b - a)) >> 8))
}

struct Extra {
    run: u32,
    mt: Vec<i32>,
}

impl Extra {
    fn new() -> Self {
        Extra { run: 0, mt: vec![-1; 1 << MATCH_BITS] }
    }
    fn reset(&mut self) {
        self.run = 0;
        self.mt.fill(-1);
    }
}

#[inline(always)]
fn match_key(l: i32, u: i32, ul: i32, plane: i32) -> usize {
    let mut h = (l as u32).wrapping_mul(0x9E37_79B1);
    h ^= (u as u32).wrapping_mul(0x85EB_CA77);
    h ^= (ul as u32).wrapping_mul(0xC2B2_AE3D);
    h ^= (plane as u32).wrapping_mul(0x27D4_EB2F);
    (h >> (32 - MATCH_BITS)) as usize
}

#[allow(clippy::too_many_arguments)]
fn code_sample<const ENC: bool, C: BitCoder>(
    cm: &mut Cm,
    coder: &mut C,
    dm: &mut DmModel,
    s: &mut Frame,
    buf: &mut [u8],
    ex: &mut Extra,
    ch: usize,
    y: usize,
    rates: [u32; 8],
    t: &Tune,
) {
    begin_sample(dm, s);
    if fast_ctx() {
        dm.ctx48 = 0;
        dm.nctx = 0;
    } else {
        match s.plane {
            2 => ctx_green(dm, s, buf),
            1 => ctx_blue(dm, s, buf),
            _ => ctx_red(dm, s, buf),
        }
    }
    let ncap = {
        static N: OnceLock<usize> = OnceLock::new();
        *N.get_or_init(|| std::env::var("ACM_NCTX").or_else(|_| std::env::var("R4_NCTX")).ok().and_then(|v| v.parse().ok()).unwrap_or(NCTX))
    };
    let dmn = (dm.nctx.max(1) as usize).min(NCTX - 4);
    let mut xb = [0u32; 4];
    let plane_cap = plane_nctx(ch);
    let nctx = (dmn + 4).min(NCTX).min(ncap.max(1)).min(plane_cap.max(1));
    let mut buckets = [0u32; NCTX];
    for j in 0..dmn {
        buckets[j] = ((dm.ctx[j] / 11264) as u32) & 0xFFF;
    }

    let px_off = s.px_off as usize;
    let stride = s.stride as usize;
    let x = s.x as usize;
    let yy = s.y as usize;
    let plane = s.plane;
    let l = if x > 0 { buf[px_off - 3] as i32 } else { 0 };
    let u = if yy > 0 { buf[px_off - stride] as i32 } else { l };
    let ul = if yy > 0 && x > 0 { buf[px_off - stride - 3] as i32 } else { u };
    let l2 = if x > 1 { buf[px_off - 6] as i32 } else { l };

    let mut edge = 0usize;
    // 44: horizontal run length ending at the left pixel, with the value.
    let run_class = ex.run.min(4).saturating_sub(1);
    xb[0] = ((l as u32) & 0xFC) | run_class;
    // 45: anti-aliased edge prediction (chroma) / strongest-contrast nbr (G).
    if plane == 2 {
        let ur = if yy > 0 && (x as i64) + 1 < s.w {
            buf[px_off - stride + 3] as i32
        } else {
            u
        };
        let alt = [u, ul, ur]
            .into_iter()
            .max_by_key(|v| (v - l).abs())
            .unwrap_or(l);
        xb[1] = (alt as u32) & 0xFFF;
    } else {
        let g = buf[px_off + 2 - plane as usize] as i32;
        let gl = if x > 0 { buf[px_off - 3 + 2 - plane as usize] as i32 } else { g };
        let gu = if yy > 0 { buf[px_off - stride + 2 - plane as usize] as i32 } else { g };
        let gul = if yy > 0 && x > 0 {
            buf[px_off - stride - 3 + 2 - plane as usize] as i32
        } else { g };
        let gur = if yy > 0 && (x as i64) + 1 < s.w {
            buf[px_off - stride + 3 + 2 - plane as usize] as i32
        } else { g };
        let pred = alpha_pred(g, [gl, gu, gul, gur], [l, u, ul, u]);
        xb[1] = (pred as u32) & 0xFFF;
        edge = ((((g - gl).abs() + (g - gu).abs()) >> 5) as usize).min(15);
    }
    // 46: 2D match model keyed on (left, up, up-left, plane).
    let mkey = match_key(l, u, ul, plane);
    let mpos = ex.mt[mkey];
    let mut mb = 2048u32;
    if mpos >= 0 {
        let mp = mpos as usize;
        let mut q = 0u32;
        if x > 0 && mp >= 3 && buf[mp - 3] as i32 == l {
            q += 1;
        }
        if yy > 0 && mp >= stride && buf[mp - stride] as i32 == u {
            q += 1;
        }
        if q > 0 {
            mb = (buf[mp] as u32) | (q << 8);
        }
    }
    xb[2] = mb;
    // 47: two-left predictor with a residual-class side channel.
    xb[3] = ((l2 as u32) & 0xF8) | (((l - l2).unsigned_abs() >> 3).min(7));
    // Keep the cheap anime contexts in the active set even when the context
    // budget is small: [0..keep) deepmix + [keep..keep+4) anime extras.
    let keep = nctx.saturating_sub(4);
    buckets[keep..keep + 4].copy_from_slice(&xb);

    let px = Frame::sample(buf, s.px_off) as i32;
    let mut val = 0i32;
    let mut c0: usize = 1;
    let mut hist: usize = 1;
    let d = dm.ctx48 as u32;
    let desc = ((d ^ (d >> 8) ^ (d >> 16)) & 0xFF) as usize;
    for k in 0..8usize {
        let chb = ch * 256;
        let mix_sels = if sel_mode() == 1 {
            let u48 = d;
            let bp = k as i32;
            let m = crate::cm3::MIX_SETS - 1;
            let nm = cm.nmix;
            let mut ms = [0usize; crate::cm4::N_MIX1];
            ms[0] = (c0 as i32 & m as i32) as usize;
            if nm > 1 {
                ms[1] = if nm == 2 {
                    mix_sel_one(sel2(), c0, bp, u48, hist, m as i32)
                } else {
                    ((256 + (bp | ((2 * dm.ctx48) & 0x78))) & m as i32) as usize
                };
            }
            if nm > 2 {
                ms[2] = ((384 + (c0 as i32 | (((dm.ctx48 as u16 as i32) << 6) & 0xF00))) & m as i32) as usize;
            }
            if nm > 3 {
                ms[3] = ((4480 + (((dm.ctx48 & 0x20 != 0) as i32) | ((u48 >> 11) & 0x1FE) as i32)) & m as i32) as usize;
            }
            if nm > 4 {
                ms[4] = ((4992 + ((u48 >> 8) & 0xF) as i32 + ((u48 >> 2) & 0xF) as i32) & m as i32) as usize;
            }
            if nm > 5 {
                ms[5] = ((5024 + (dm.ctx48 as u8 as i32)) & m as i32) as usize;
            }
            if nm > 6 {
                ms[6] = ((5280 + (((c0 as i32) << bp) | (hist as i32 & ((1 << bp) - 1)))) & m as i32) as usize;
            }
            ms
        } else if sel_mode() == 2 {
            [
                c0 & 255,
                ((((desc >> 3) << 3) | (k & 7)) & 255),
                (((c0 & 0x3F) | ((desc & 3) << 6)) & 255),
                desc,
                ((desc.rotate_left(3)) & 0xFF),
                (((k << 5) | (desc >> 3)) & 255),
                ((c0 & 255) ^ (hist & 255)),
            ]
        } else {
        [
            chb + (c0 & 255),
            chb + ((((desc >> 3) << 3) | (k & 7)) & 255),
            chb + (((c0 & 0x3F) | ((desc & 3) << 6)) & 255),
            chb + desc,
            chb + ((desc.rotate_left(3)) & 0xFF),
            chb + (((k << 5) | (desc >> 3)) & 255),
            chb + ((c0 & 255) ^ (hist & 255)),
        ]
        };
        let apm_en = apm_planes()[ch];
        cm.apm_now = apm_en;
        let apm_sels = if apm_en {
            if plane == 2 {
                [chb + desc, chb + (c0 & 255)]
            } else {
                [chb + ((edge << 4) | (c0 & 15)), chb + desc]
            }
        } else {
            [0, 0]
        };
        let rate = if t.dm_rates {
            rates[k]
        } else if k < 4 {
            t.rhi
        } else {
            t.rlo
        };
        let (bit, p) = cm.code_bit::<ENC, C>(
            coder,
            (px >> (7 - k)) & 1,
            &buckets,
            nctx,
            c0,
            mix_sels,
            apm_sels,
            if sel_mode() == 1 { k } else { ch * 8 + k },
            rate,
            t.lr,
        );
        val = (val << 1) | bit;
        c0 = c0 * 2 + bit as usize;
        let wrong = ((p >= 2048) as i32 != bit) as usize;
        hist = ((hist << 1) | wrong) & 0xFF;
    }
    if !ENC {
        buf[s.px_off as usize] = val as u8;
    }
    ex.mt[mkey] = s.px_off as i32;
    ex.run = if x > 0 && val == l { ex.run + 1 } else { 1 };
    advance_pixel(s);
    s.px_off += 3;
    let _ = y;
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn new_model() -> Cm {
    if std::env::var("R4_INIT").ok().as_deref() == Some("dm") {
        Cm::new_dm()
    } else {
        Cm::new_with_prior(&kinds())
    }
}

pub(crate) fn run_plane<const ENC: bool, C: BitCoder>(
    w: usize,
    h: usize,
    plane: i32,
    buf: &mut [u8],
    cm: &mut Cm,
    dm: &mut DmModel,
    coder: &mut C,
    mut before_row: Option<&mut dyn FnMut(usize, &mut [u8])>,
    mut after_row: Option<&mut dyn FnMut(usize, &[u8])>,
) {
    let t = tune();
    let mut s = Frame::new(w, h);
    let ch = (2 - plane) as usize;
    cm.nmix = plane_mix()[ch];
    s.plane = plane;
    s.plane_count = -plane;
    s.y = 0;
    s.row_off = plane as i64;
    s.green_row_off = plane as i64;
    s.prev_plane_a = s.prev_plane;
    s.y_scan = 0;
    s.y_row = 0;
    s.y_next = 1;
    s.y16 = 0;
    s.rate_base = 4;
    s.px_off = s.row_off;
    s.x = 0;
    let mut ex = Extra::new();
    ex.reset();
    begin_row(&mut s, buf);
    for y in 0..h {
        let rates = dm_rates(y as i64);
        ex.run = 0;
        s.x = 0;
        if let Some(f) = &mut before_row {
            f(y, buf);
        }
        for x in 0..w {
            s.x = x as i64;
            s.x_next = x as i64 + 1;
            load_neighbours(&mut s, buf);
            code_sample::<ENC, C>(cm, coder, dm, &mut s, buf, &mut ex, ch, y, rates, t);
        }
        if let Some(f) = &mut after_row {
            f(y, buf);
        }
        if y + 1 < h {
            let ny = y as i64 + 1;
            s.y_next = ny;
            s.y = ny;
            s.y_row = ny;
            s.y_scan = ny;
            s.y16 = 16 * ny;
            s.rate_base = 5 - ((ny < 5) as i32);
            s.row_off += s.stride;
            begin_row(&mut s, buf);
        }
    }
    if std::env::var("R4_STATS").ok().as_deref() == Some("1") {
        let bits = cm.cost;
        eprintln!(
            "plane {} cost {:.0} bits {:.4} bpp",
            plane,
            bits,
            bits / (w * h) as f64
        );
        cm.cost = 0.0;
    }
}

fn walk<const ENC: bool, C: BitCoder>(w: usize, h: usize, buf: &mut [u8], coder: &mut C) {
    let mut dm = DmModel::new();
    let mut cm = new_model();
    run_plane::<ENC, C>(w, h, 2, buf, &mut cm, &mut dm, coder, None, None);
    if std::env::var("R4_FORK").ok().as_deref() == Some("1") {
        let mut cmb = cm.clone();
        let mut cmr = cm.clone();
        run_plane::<ENC, C>(w, h, 1, buf, &mut cmb, &mut dm, coder, None, None);
        run_plane::<ENC, C>(w, h, 0, buf, &mut cmr, &mut dm, coder, None, None);
    } else {
        run_plane::<ENC, C>(w, h, 1, buf, &mut cm, &mut dm, coder, None, None);
        run_plane::<ENC, C>(w, h, 0, buf, &mut cm, &mut dm, coder, None, None);
    }
}

pub fn encode_rgb(rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
    let n = w * h;
    let mut buf = vec![0u8; n * 3];
    for i in 0..n {
        buf[i * 3] = rgb[i * 3]; // R
        buf[i * 3 + 1] = rgb[i * 3 + 2]; // B
        buf[i * 3 + 2] = rgb[i * 3 + 1]; // G
    }
    let mut coder = rc::Encoder::new();
    walk::<true, _>(w, h, &mut buf, &mut coder);
    let payload = coder.finish();
    let mut out = Vec::with_capacity(payload.len() + 12);
    out.extend_from_slice(MAGIC);
    out.extend_from_slice(&(w as u32).to_le_bytes());
    out.extend_from_slice(&(h as u32).to_le_bytes());
    out.extend_from_slice(&payload);
    out
}

pub fn decode_rgb(data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
    if data.len() < 12 || &data[0..4] != MAGIC {
        return Err("bad AC14 header".into());
    }
    let w = u32::from_le_bytes(data[4..8].try_into().unwrap()) as usize;
    let h = u32::from_le_bytes(data[8..12].try_into().unwrap()) as usize;
    if w == 0 || h == 0 || w.checked_mul(h).map_or(true, |n| n > 1 << 30) {
        return Err("bad dimensions".into());
    }
    let mut buf = vec![0u8; w * h * 3];
    let mut dec = rc::Decoder::new(&data[12..]);
    walk::<false, _>(w, h, &mut buf, &mut dec);
    let n = w * h;
    let mut rgb = vec![0u8; n * 3];
    for i in 0..n {
        rgb[i * 3] = buf[i * 3];
        rgb[i * 3 + 1] = buf[i * 3 + 2];
        rgb[i * 3 + 2] = buf[i * 3 + 1];
    }
    Ok((rgb, w, h))
}

pub struct R4;

impl Codec for R4 {
    fn name(&self) -> &'static str {
        "r4-anime"
    }
    fn encode(&self, rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
        encode_rgb(rgb, w, h)
    }
    fn decode(&self, data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
        decode_rgb(data)
    }
}
