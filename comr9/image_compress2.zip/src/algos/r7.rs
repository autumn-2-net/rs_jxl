//! Round 6: content-adaptive choice between absolute RGB (r4) and
//! green-residual chroma (r6), signalled in the container.
//!
//! Residual chroma pays off on near-monochrome artwork (small mean |R-G|,
//! |B-G|) and loses on richly coloured images, where the reference context
//! set is built around absolute channel values. The encoder measures the
//! global chroma magnitude and picks a branch; one flag byte tells the
//! decoder which one.

use crate::algos::{r4, r6};
use crate::Codec;

const MAGIC: &[u8; 4] = b"AC17";

fn chroma_score(rgb: &[u8]) -> u64 {
    let n = rgb.len() / 3;
    if n == 0 {
        return 0;
    }
    let step = (n / 200_000).max(1);
    let mut sum = 0u64;
    let mut cnt = 0u64;
    let mut i = 0;
    while i < n {
        let o = i * 3;
        let g = rgb[o + 1] as i32;
        sum += (rgb[o] as i32 - g).unsigned_abs() as u64;
        sum += (rgb[o + 2] as i32 - g).unsigned_abs() as u64;
        cnt += 1;
        i += step;
    }
    sum / cnt.max(1)
}

fn threshold() -> u64 {
    std::env::var("R7_T")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(40)
}

pub fn encode_rgb(rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
    let use_res = chroma_score(rgb) < threshold();
    let payload = if use_res {
        r6::encode_rgb(rgb, w, h)
    } else {
        r4::encode_rgb(rgb, w, h)
    };
    let mut out = Vec::with_capacity(payload.len() + 5);
    out.extend_from_slice(MAGIC);
    out.push(use_res as u8);
    out.extend_from_slice(&payload);
    out
}

pub fn decode_rgb(data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
    if data.len() < 5 || &data[0..4] != MAGIC {
        return Err("bad AC17 header".into());
    }
    let flag = data[4];
    let payload = &data[5..];
    if flag == 1 {
        r6::decode_rgb(payload)
    } else {
        r4::decode_rgb(payload)
    }
}

pub struct R7;

impl Codec for R7 {
    fn name(&self) -> &'static str {
        "r7-adaptive"
    }
    fn encode(&self, rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
        encode_rgb(rgb, w, h)
    }
    fn decode(&self, data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
        decode_rgb(data)
    }
}
