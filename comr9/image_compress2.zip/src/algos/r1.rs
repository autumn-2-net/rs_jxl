//! Round 1: "AnimeCM v1" — 16-context bitwise CM with nibble-split tables,
//! anime-oriented predictors and a run-continuation fast path.
//!
//! Planes are coded G -> B -> R. B and R may use the fully decoded G plane;
//! R may also use the fully decoded B plane. Within a row, a channel-level
//! run of identical samples is coded with one continuation bit per further
//! sample, skipping the context-mixing model entirely.

use crate::cm::{BitCoder, Cm, NCTX};
use crate::rc;
use crate::Codec;
use std::sync::OnceLock;

const MAGIC: &[u8; 4] = b"AC11";
const MARGIN: usize = 6;

const fn build_recip() -> [u32; 256] {
    let mut r = [0u32; 256];
    let mut i = 1usize;
    while i < 256 {
        r[i] = 65536 / (i as u32);
        i += 1;
    }
    r
}
static RECIP: [u32; 256] = build_recip();

/// Context kinds for the counter prior: 0 = none, 1 = activity-sided
/// prediction, 2 = gradient-sided prediction, 3 = 16-bit primary context.
const KINDS_G: [u8; NCTX] = [
    3, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 2, 2, 2, 0, 2,
];
const KINDS_C: [u8; NCTX] = [
    3, 1, 2, 1, 2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
];


#[inline(always)]
fn hash16(x: u32) -> u32 {
    let mut h = x.wrapping_mul(0x9E37_79B1);
    h ^= h >> 15;
    h & 0xFFFF
}

struct Tune {
    rhi: u32,
    rlo: u32,
    lr: i32,
}

fn tune() -> &'static Tune {
    static T: OnceLock<Tune> = OnceLock::new();
    T.get_or_init(|| {
        let get = |k: &str, d: i64| {
            std::env::var(k).ok().and_then(|v| v.parse().ok()).unwrap_or(d)
        };
        Tune {
            rhi: get("R1_RHI", 2) as u32,
            rlo: get("R1_RLO", 3) as u32,
            lr: get("R1_LR", 20) as i32,
        }
    })
}

#[inline(always)]
fn clamp255(v: i32) -> i32 {
    v.clamp(0, 255)
}

#[inline(always)]
fn med3(a: i32, b: i32, c: i32) -> i32 {
    let hi = a.max(b);
    let lo = a.min(b);
    c.max(lo).min(hi)
}

#[inline(always)]
fn act_class(l: i32, u: i32, ul: i32, ur: i32) -> u32 {
    let a = (l - u).abs() + (l - ul).abs() + (u - ur).abs();
    let q = a.max(1).ilog2().min(7);
    ((q << 1) | ((l == u) as u32)) & 15
}

#[inline(always)]
fn alpha_pred(g: i32, gs: [i32; 4], cs: [i32; 4]) -> i32 {
    let mut imin = 0usize;
    let mut imax = 0usize;
    for i in 1..4 {
        if gs[i] < gs[imin] {
            imin = i;
        }
        if gs[i] > gs[imax] {
            imax = i;
        }
    }
    let denom = gs[imax] - gs[imin];
    if denom <= 0 {
        return cs[0];
    }
    let num = (g - gs[imin]).clamp(0, denom) as u32;
    let alpha = (num * RECIP[denom as usize]) >> 8; // 0..=256
    let a = cs[imin];
    let b = cs[imax];
    clamp255(a + ((alpha as i32 * (b - a)) >> 8))
}


#[inline(always)]
fn buckets_g(cur: &[u8], idx: usize, stride: usize, err_hist: u32) -> ([u32; NCTX], u32, u32, i32) {
    let l = cur[idx - 1] as i32;
    let l2 = cur[idx - 2] as i32;
    let l3 = cur[idx - 3] as i32;
    let l4 = cur[idx - 4] as i32;
    let l5 = cur[idx - 5] as i32;
    let u = cur[idx - stride] as i32;
    let u2 = cur[idx - 2 * stride] as i32;
    let u3r = cur[idx - 3 * stride + 1] as i32;
    let u2r = cur[idx - 2 * stride + 1] as i32;
    let ul = cur[idx - stride - 1] as i32;
    let ur = cur[idx - stride + 1] as i32;

    let ac = act_class(l, u, ul, ur);
    let gs = ((l > u) as u32)
        | (((u > ul) as u32) << 1)
        | (((ul > l2) as u32) << 2)
        | (((u > ur) as u32) << 3);
    let sum6 = u3r + 3 * (ur - u2r) - 20 * l2 + 15 * l3 - 6 * l4 + l5 + 15 * l;
    let pred6 = clamp255(sum6 / 6);
    let med = med3(l, u, ul);

    let dh = (l - l2).abs() + (u - ul).abs() + (u - ur).abs();
    let dv = (l - ul).abs() + (u - u2).abs() + (u - ur).abs();
    let d = dv - dh;
    let gap = if d > 24 {
        l
    } else if d > 8 {
        (3 * l + u + 2) >> 2
    } else if d < -24 {
        u
    } else if d < -8 {
        (l + 3 * u + 2) >> 2
    } else {
        med
    };

    let planar = clamp255(l + u - ul);
    let avg = (l + u + 1) >> 1;
    let h2 = clamp255(2 * l - l2);
    let v2 = clamp255(2 * u - u2);
    let wl = (3 * l + u + 2) >> 2;
    let wu = (l + 3 * u + 2) >> 2;
    let diag = clamp255((l + ur + 1) >> 1);
    let edge = if (u - ul).abs() < (l - ul).abs() { u } else { l };
    let four = (l + u + ul + ur + 2) >> 2;
    let min4 = l.min(u).min(ul).min(ur);
    let max4 = l.max(u).max(ul).max(ur);

    let rng = (l.max(u).max(ul).max(ur) - l.min(u).min(ul).min(ur)) as u32;
    let tex = (((rng >> 4) << 4) | ac) & 0xFF;

    let bk_s = |p: i32| -> u32 { (((p as u32) & 0xFF) << 4) | gs };
    let bk_a = |p: i32| -> u32 { (((p as u32) & 0xFF) << 4) | ac };
    let comp = |v: i32, side: u32| -> u32 { (((v as u32) & 0xFF) << 4) | side };

    let nb = (l as u32) | ((u as u32) << 8) | ((ul as u32) << 16) | ((ur as u32) << 24);
    let b = [
        (ac | (gs << 4) | (((med as u32) & 0xFF) << 8)) & 0xFFFF,
        hash16(nb),
        bk_s(gap),
        bk_a(gap),
        bk_s(planar),
        bk_a(planar),
        bk_a(avg),
        bk_a(h2),
        bk_a(v2),
        bk_a(wl),
        bk_a(wu),
        bk_a(diag),
        bk_a(edge),
        bk_s(pred6),
        bk_a(pred6),
        bk_s(l),
        bk_a(u),
        bk_a(ul),
        bk_a(ur),
        comp((med & 0xF8) | (l >> 5), gs),
        comp((med & 0xF8) | (u >> 5), gs),
        comp((med & 0xFC) | (((l == u) as i32) << 1) | ((l == ul) as i32), gs),
        comp((l & 0xF8) | (u >> 5), ac),
        comp((u & 0xF8) | (l >> 5), ac),
        comp((ul & 0xF8) | (ur >> 5), ac),
        comp((med - l) & 0xFF, ac),
        comp((med - u) & 0xFF, ac),
        comp((2 * med - l - u) & 0xFF, ac),
        comp((med + ur - u) & 0xFF, ac),
        comp(tex as i32, gs),
        comp((err_hist & 0xFF) as i32, gs),
        comp(((gs << 4) | ac) as i32, (med as u32) >> 4),
        comp(four, ac),
        comp(min4, ac),
        comp(max4, ac),
        comp((l + ur + 1) >> 1, ac),
        comp((u + ul + 1) >> 1, ac),
        comp((med + (l - l2)) & 0xFF, ac),
        comp((med + (u - u2)) & 0xFF, ac),
        comp((med + (((ur - u) + (l - ul)) >> 1)) & 0xFF, gs),
        comp((med + (((l - ul) + (u - ul)) >> 1)) & 0xFF, ac),
        comp((l2 & 0xF8) | (u2 >> 5), ac),
        comp((u & 0xF0) | (ur >> 4), gs),
        comp(h2 & 0xFF, gs),
        comp(v2 & 0xFF, gs),
        comp(avg & 0xFF, gs),
        comp(((err_hist >> 4) & 0xF) as i32 | (((med & 0xF) as i32) << 4), ac),
        comp(four, gs),
    ];
    (b, ac, gs, med)
}

#[inline(always)]
#[allow(clippy::too_many_arguments)]
fn buckets_c(
    ch: usize,
    cur: &[u8],
    gp: &[u8],
    bp: &[u8],
    idx: usize,
    stride: usize,
    err_hist: u32,
) -> ([u32; NCTX], u32, u32, i32) {
    let l = cur[idx - 1] as i32;
    let l2 = cur[idx - 2] as i32;
    let l3 = cur[idx - 3] as i32;
    let l4 = cur[idx - 4] as i32;
    let l5 = cur[idx - 5] as i32;
    let u = cur[idx - stride] as i32;
    let u2 = cur[idx - 2 * stride] as i32;
    let ul = cur[idx - stride - 1] as i32;
    let ur = cur[idx - stride + 1] as i32;
    let u3r = cur[idx - 3 * stride + 1] as i32;
    let u2r = cur[idx - 2 * stride + 1] as i32;
    let gl2 = gp[idx - 2] as i32;
    let gl3 = gp[idx - 3] as i32;
    let gl4 = gp[idx - 4] as i32;
    let gl5 = gp[idx - 5] as i32;
    let gu3r = gp[idx - 3 * stride + 1] as i32;
    let gu2r = gp[idx - 2 * stride + 1] as i32;
    let gu2 = gp[idx - 2 * stride] as i32;

    let g = gp[idx] as i32;
    let gr = gp[idx + 1] as i32;
    let gd = gp[idx + stride] as i32;
    let gl = gp[idx - 1] as i32;
    let gu = gp[idx - stride] as i32;
    let gul = gp[idx - stride - 1] as i32;
    let gur = gp[idx - stride + 1] as i32;

    let ac = act_class(l, u, ul, ur);
    let gs = ((g > gl) as u32)
        | (((g > gu) as u32) << 1)
        | (((gl > gul) as u32) << 2)
        | (((g > gur) as u32) << 3);
    let gs2 = ((g > gl) as u32)
        | (((g > gr) as u32) << 1)
        | (((g > gu) as u32) << 2)
        | (((g > gd) as u32) << 3);
    let med = med3(l, u, ul);

    let p1 = clamp255(l + (g - gl));
    let p2 = clamp255(u + (g - gu));
    let p3 = clamp255(((l + u + 1) >> 1) + g - ((gl + gu + 1) >> 1));
    let p4 = clamp255(clamp255(l + u - ul) + g - clamp255(gl + gu - gul));
    let p5 = clamp255(g + med3(l - gl, u - gu, ul - gul));
    let alpha = alpha_pred(g, [gl, gu, gul, gur], [l, u, ul, ur]);
    let p7 = clamp255(g + (((l - gl) + (u - gu) + 1) >> 1));
    let p8 = clamp255((p1 + p2 + 1) >> 1);
    let p9 = clamp255(med + (g - med3(gl, gu, gul)));
    let p10 = if (g - gl).abs() < (g - gu).abs() { p1 } else { p2 };
    let p11 = clamp255(l + (g - gl) + ((l - ul) - (gl - gul)));
    let sum6c = u3r + 3 * (ur - u2r) - 20 * l2 + 15 * l3 - 6 * l4 + l5 + 15 * l;
    let sum6g = gu3r + 3 * (gur - gu2r) - 20 * gl2 + 15 * gl3 - 6 * gl4 + gl5 + 15 * gl;
    let p6 = clamp255(g + (sum6c / 6 - sum6g / 6));

    let rngg = (g.max(gl).max(gu).max(gur) - g.min(gl).min(gu).min(gur)) as u32;
    let rngc = (l.max(u).max(ul).max(ur) - l.min(u).min(ul).min(ur)) as u32;
    let tex = ((((rngg + rngc) >> 5) << 4) | ac) & 0xFF;

    let bk_s = |p: i32| -> u32 { (((p as u32) & 0xFF) << 4) | gs };
    let bk_a = |p: i32| -> u32 { (((p as u32) & 0xFF) << 4) | ac };
    let comp = |v: i32, side: u32| -> u32 { (((v as u32) & 0xFF) << 4) | side };

    let nb = (l as u32)
        | ((u as u32) << 8)
        | ((ul as u32) << 16)
        | ((ur as u32) << 24);
    let nbg = (g as u32) | ((gl as u32) << 8) | ((gu as u32) << 16) | ((gur as u32) << 24);
    let mut b = [
        (ac | (gs << 4) | ((med as u32) << 8)) & 0xFFFF,
        hash16(nb ^ nbg.rotate_left(11)),
        bk_s(p1),
        bk_a(p1),
        bk_s(p2),
        bk_a(p2),
        bk_a(p3),
        bk_a(p4),
        bk_a(p5),
        bk_s(p5),
        bk_a(alpha),
        bk_s(alpha),
        bk_a(p7),
        bk_a(p8),
        bk_a(p9),
        bk_a(p10),
        bk_a(p11),
        bk_a(p6),
        bk_s(p6),
        comp((g & 0xF8) | (gr >> 5), gs2),
        comp((g & 0xF8) | (gd >> 5), gs2),
        comp((med & 0xF8) | (g >> 5), gs),
        comp((l & 0xF8) | (g >> 5), ac),
        comp((p5 - l) & 0xFF, ac),
        comp((p5 - u) & 0xFF, ac),
        comp((2 * p5 - p1 - p2) & 0xFF, ac),
        comp((med & 0xFC) | (((l == u) as i32) << 1) | ((l == ul) as i32), gs),
        comp(tex as i32, gs),
        comp((err_hist & 0xFF) as i32, gs),
        comp(((gs << 4) | ac) as i32, (g as u32) >> 4),
        comp((g & 0xFC) | (((g > gr) as i32) << 1) | ((g > gd) as i32), ac),
        bk_a(med),
        comp((g + (l - gl) + ((l - gl) - (l2 - gl2))) & 0xFF, ac),
        comp((g + (u - gu) + ((u - gu) - (u2 - gu2))) & 0xFF, ac),
        comp(p4 & 0xFF, gs),
        comp(p5 & 0xFF, gs),
        comp(alpha & 0xFF, ac),
        comp(p6 & 0xFF, gs),
        comp(p7 & 0xFF, gs),
        comp(p8 & 0xFF, gs),
        comp(p9 & 0xFF, gs),
        comp(p10 & 0xFF, gs),
        comp(p11 & 0xFF, gs),
        comp((l + (g - gl) + (gr - g)) & 0xFF, ac),
        comp((u + (g - gu) + (gr - g)) & 0xFF, ac),
        comp((g + med3(l - gl, u - gu, ul - gul) + (gr - g)) & 0xFF, ac),
        comp((g + (((l - gl) + (u - gu) + (gr - g) + (gd - g)) >> 2)) & 0xFF, ac),
        comp((((err_hist >> 4) & 0xF) as i32) | (((g & 0xF) as i32) << 4), ac),
    ];

    if ch == 2 && !bp.is_empty() {
        let bv = bp[idx] as i32;
        let bl = bp[idx - 1] as i32;
        let bu = bp[idx - stride] as i32;
        let bul = bp[idx - stride - 1] as i32;
        let q0 = clamp255(bv + (l - bl));
        let q2 = clamp255(bv + med3(l - bl, u - bu, ul - bul));
        let q3 = clamp255(bv + (((l - bl) + (u - bu) + 1) >> 1));
        let q4 = clamp255(bv + (med - med3(bl, bu, bul)));
        b[29] = bk_s(q0);
        b[30] = bk_a(q2);
        b[31] = bk_s(q4);
    }

    (b, ac, gs, med)
}

/// Padded plane layout: `MARGIN` pixels on each side, top and bottom.
#[inline]
fn stride_for(w: usize) -> usize {
    w + 2 * MARGIN
}

fn pad_from(src: &[u8], w: usize, h: usize) -> Vec<u8> {
    let stride = stride_for(w);
    let mut p = vec![0u8; (h + 2 * MARGIN) * stride];
    for y in 0..h {
        let d = (y + MARGIN) * stride + MARGIN;
        p[d..d + w].copy_from_slice(&src[y * w..(y + 1) * w]);
    }
    p
}

#[allow(clippy::too_many_arguments)]
fn code_plane<const ENC: bool, C: BitCoder>(
    cm: &mut Cm,
    coder: &mut C,
    ch: usize,
    w: usize,
    h: usize,
    stride: usize,
    plane: &mut [u8],
    cur: &mut [u8],
    gp: &[u8],
    bp: &[u8],
) {
    let t = tune();
    let stats = std::env::var_os("R1_STATS").is_some();
    let mut flat_bits = 0.0f64;
    let mut nonflat_bits = 0.0f64;
    let mut flat_n = 0u64;
    let mut nonflat_n = 0u64;
    let mut err_hist: u32 = 0;
    for y in 0..h {
        let row_base = (y + MARGIN) * stride + MARGIN;
        let mut run_len: u32 = 0;
        let slow = if y >= 512 {
            2u32
        } else if y >= 64 {
            1u32
        } else {
            0u32
        };
        for x in 0..w {
            let idx = row_base + x;
            let l = cur[idx - 1] as i32;
            let u = cur[idx - stride] as i32;
            let ul = cur[idx - stride - 1] as i32;

            if false && x > 0 && run_len >= 2 {
                let rctx = (((run_len.min(32) - 2).min(15) as usize) << 3)
                    | (((l == u) as usize) << 2)
                    | (((u == ul) as usize) << 1)
                    | ((l == ul) as usize);
                let cont = if ENC {
                    (plane[y * w + x] as i32 == l) as i32
                } else {
                    0
                };
                if cm.code_run::<ENC, C>(coder, cont, rctx) != 0 {
                    let val = l as u8;
                    cur[idx] = val;
                    if !ENC {
                        plane[y * w + x] = val;
                    }
                    run_len += 1;
                    continue;
                }
                run_len = 0;
            }

            let (buckets, ac, gs, medp) = if ch == 0 {
                buckets_g(cur, idx, stride, err_hist)
            } else {
                buckets_c(ch, cur, gp, bp, idx, stride, err_hist)
            };

            let cost_before = cm.cost;
            let src = if ENC { plane[y * w + x] as i32 } else { 0 };
            let mut val = 0i32;
            let mut node = 1usize;
            let mut c0_full = 1usize;
            let mut high = 0u32;
            let mut hist: usize = 1;
            for k in 0..4usize {
                let slot = node - 1;
                let desc = ((gs as usize) << 4) | ac as usize;
                let c0 = c0_full & 255;
                let chb = ch * 256;
                let mix_sels = [
                    chb + c0,
                    chb + (((desc >> 3) << 3) | (k & 7)),
                    chb + ((c0 & 0x3F) | ((desc & 3) << 6)),
                    chb + desc,
                    chb + (((desc.rotate_left(3)) & 0xFF)),
                    chb + ((k << 5) | (desc >> 3)),
                    chb + (c0 ^ (hist & 255)),
                ];
                let apm_sels = [chb + desc, chb + c0];
                let (bit, p) = cm.code_bit::<ENC, C>(
                    coder,
                    (src >> (7 - k)) & 1,
                    &buckets,
                    false,
                    0,
                    slot,
                    mix_sels,
                    apm_sels,
                    ch * 8 + k,
                    t.rhi + slow,
                    t.lr,
                );
                val = (val << 1) | bit;
                high = (high << 1) | bit as u32;
                node = node * 2 + bit as usize;
                c0_full = c0_full * 2 + bit as usize;
                let wrong = ((p >= 2048) as i32 != bit) as usize;
                hist = ((hist << 1) | wrong) & 0xFF;
            }
            node = 1;
            let low_xor = high << 8;
            for k in 4..8usize {
                let slot = 15 + node - 1;
                let desc = ((gs as usize) << 4) | ac as usize;
                let c0 = c0_full & 255;
                let chb = ch * 256;
                let mix_sels = [
                    chb + c0,
                    chb + (((desc >> 3) << 3) | (k & 7)),
                    chb + ((c0 & 0x3F) | ((desc & 3) << 6)),
                    chb + desc,
                    chb + (((desc.rotate_left(3)) & 0xFF)),
                    chb + ((k << 5) | (desc >> 3)),
                    chb + (c0 ^ (hist & 255)),
                ];
                let apm_sels = [chb + desc, chb + c0];
                let (bit, p) = cm.code_bit::<ENC, C>(
                    coder,
                    (src >> (7 - k)) & 1,
                    &buckets,
                    true,
                    low_xor,
                    slot,
                    mix_sels,
                    apm_sels,
                    ch * 8 + k,
                    t.rlo + slow,
                    t.lr,
                );
                val = (val << 1) | bit;
                node = node * 2 + bit as usize;
                c0_full = c0_full * 2 + bit as usize;
                let wrong = ((p >= 2048) as i32 != bit) as usize;
                hist = ((hist << 1) | wrong) & 0xFF;
            }
            cur[idx] = val as u8;
            if !ENC {
                plane[y * w + x] = val as u8;
            }

            if x > 0 && val == l {
                run_len += 1;
            } else {
                run_len = 0;
            }

            let res = (val - medp).abs();
            let cls = if res == 0 {
                0
            } else if res < 4 {
                1
            } else if res < 16 {
                2
            } else {
                3
            };
            err_hist = ((err_hist << 2) | cls) & 0xFF;
            if stats {
                let pc = cm.cost - cost_before;
                if x > 0 && (val == l || val == u) {
                    flat_bits += pc;
                    flat_n += 1;
                } else {
                    nonflat_bits += pc;
                    nonflat_n += 1;
                }
            }
        }
    }
    if stats {
        eprintln!(
            "  plane {} flat: {} px {:.3} bit/px | nonflat: {} px {:.3} bit/px",
            ch, flat_n, flat_bits / (flat_n.max(1) as f64),
            nonflat_n, nonflat_bits / (nonflat_n.max(1) as f64)
        );
    }
}

fn split_planes(rgb: &[u8], w: usize, h: usize) -> (Vec<u8>, Vec<u8>, Vec<u8>) {
    let n = w * h;
    let mut g = vec![0u8; n];
    let mut b = vec![0u8; n];
    let mut r = vec![0u8; n];
    for i in 0..n {
        r[i] = rgb[i * 3];
        g[i] = rgb[i * 3 + 1];
        b[i] = rgb[i * 3 + 2];
    }
    (g, b, r)
}

fn build_container(w: usize, h: usize, payload: Vec<u8>) -> Vec<u8> {
    let mut out = Vec::with_capacity(payload.len() + 16);
    out.extend_from_slice(MAGIC);
    out.extend_from_slice(&(w as u32).to_le_bytes());
    out.extend_from_slice(&(h as u32).to_le_bytes());
    out.extend_from_slice(&payload);
    out
}

pub fn encode_rgb(rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
    let (mut pg, mut pb, mut pr) = split_planes(rgb, w, h);
    let stride = stride_for(w);
    let mut gp = pad_from(&pg, w, h);
    let mut bp = pad_from(&pb, w, h);
    let mut rp = pad_from(&pr, w, h);

    let mut coder = rc::Encoder::new();
    let mut cmg = Cm::new_with_prior(&KINDS_G);
    code_plane::<true, _>(&mut cmg, &mut coder, 0, w, h, stride, &mut pg, &mut gp, &[], &[]);
    drop(cmg);
    let stats = std::env::var_os("R1_STATS").is_some();
    if stats { eprintln!("  plane G: {} bytes", coder.out.len()); }

    let mut cmb = Cm::new_with_prior(&KINDS_C);
    code_plane::<true, _>(&mut cmb, &mut coder, 1, w, h, stride, &mut pb, &mut bp, &gp, &[]);
    drop(cmb);
    if stats { eprintln!("  plane B: {} bytes cumulative", coder.out.len()); }

    let mut cmr = Cm::new_with_prior(&KINDS_C);
    code_plane::<true, _>(&mut cmr, &mut coder, 2, w, h, stride, &mut pr, &mut rp, &gp, &bp);
    if stats { eprintln!("  plane R: {} bytes cumulative", coder.out.len()); }

    let payload = coder.finish();
    build_container(w, h, payload)
}

pub fn decode_rgb(data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
    if data.len() < 12 || &data[0..4] != MAGIC {
        return Err("bad AC11 header".into());
    }
    let w = u32::from_le_bytes(data[4..8].try_into().unwrap()) as usize;
    let h = u32::from_le_bytes(data[8..12].try_into().unwrap()) as usize;
    if w == 0 || h == 0 || w.checked_mul(h).map_or(true, |n| n > 1 << 30) {
        return Err("bad dimensions".into());
    }
    let n = w * h;
    let stride = stride_for(w);
    let mut pg = vec![0u8; n];
    let mut pb = vec![0u8; n];
    let mut pr = vec![0u8; n];
    let mut gp = vec![0u8; (h + 2 * MARGIN) * stride];
    let mut bp = vec![0u8; (h + 2 * MARGIN) * stride];
    let mut rp = vec![0u8; (h + 2 * MARGIN) * stride];

    let mut dec = rc::Decoder::new(&data[12..]);
    let mut cmg = Cm::new_with_prior(&KINDS_G);
    code_plane::<false, _>(&mut cmg, &mut dec, 0, w, h, stride, &mut pg, &mut gp, &[], &[]);
    drop(cmg);
    let mut cmb = Cm::new_with_prior(&KINDS_C);
    code_plane::<false, _>(&mut cmb, &mut dec, 1, w, h, stride, &mut pb, &mut bp, &gp, &[]);
    drop(cmb);
    let mut cmr = Cm::new_with_prior(&KINDS_C);
    code_plane::<false, _>(&mut cmr, &mut dec, 2, w, h, stride, &mut pr, &mut rp, &gp, &bp);

    let mut rgb = vec![0u8; n * 3];
    for i in 0..n {
        rgb[i * 3] = pr[i];
        rgb[i * 3 + 1] = pg[i];
        rgb[i * 3 + 2] = pb[i];
    }
    Ok((rgb, w, h))
}

pub struct R1;

impl Codec for R1 {
    fn name(&self) -> &'static str {
        "r1-animecm"
    }
    fn encode(&self, rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
        encode_rgb(rgb, w, h)
    }
    fn decode(&self, data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
        decode_rgb(data)
    }
}
