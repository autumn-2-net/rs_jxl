//! Round 3: deepmix's context derivation driven by our full-tree model.
//!
//! The neighbour bank and the 37/44 context formulas are adapted from the
//! public-domain deepmix reference; the counter layout, mixer, APM stages and
//! priors are ours.

use crate::cm3::{BitCoder, Cm, NCTX};
use crate::dmctx::{
    advance_pixel, begin_row, begin_sample, ctx_blue, ctx_green, ctx_red, load_neighbours,
    next_plane, DmModel, Frame,
};
use crate::rc;
use crate::Codec;
use std::sync::OnceLock;

const MAGIC: &[u8; 4] = b"AC13";
fn kinds() -> [u8; NCTX] {
    static K: OnceLock<[u8; NCTX]> = OnceLock::new();
    *K.get_or_init(|| {
        let mut k = [1u8; NCTX];
        if let Ok(v) = std::env::var("R3_PRIOR_CTX") {
            if let Ok(n) = v.parse::<usize>() {
                for (i, x) in k.iter_mut().enumerate() {
                    if i >= n {
                        *x = 0;
                    }
                }
            }
        }
        k
    })
}

struct Tune {
    lr: i32,
    dm_rates: bool,
    rhi: u32,
    rlo: u32,
}

fn tune() -> &'static Tune {
    static T: OnceLock<Tune> = OnceLock::new();
    T.get_or_init(|| {
        let get = |k: &str, d: i64| {
            std::env::var(k).ok().and_then(|v| v.parse().ok()).unwrap_or(d)
        };
        Tune {
            lr: get("R3_LR", 3) as i32,
            dm_rates: get("R3_DMRATES", 1) != 0,
            rhi: get("R3_RHI", 2) as u32,
            rlo: get("R3_RLO", 3) as u32,
        }
    })
}

/// Deepmix's per-bit counter adaptation shifts for row `y`.
fn sel_mode() -> i32 {
    static S: OnceLock<i32> = OnceLock::new();
    *S.get_or_init(|| std::env::var("R3_SEL").ok().and_then(|v| v.parse().ok()).unwrap_or(1))
}

fn apm_on() -> bool {
    static A: OnceLock<bool> = OnceLock::new();
    *A.get_or_init(|| std::env::var("R3_APM").map(|v| v != "0").unwrap_or(false))
}

fn dm_rates(y: i64) -> [u32; 8] {
    let q50 = (y > 0x50) as u32;
    let qa0 = (y > 0xA0) as u32;
    let q10 = (y > 0x10) as u32;
    let q20 = (y > 0x20) as u32;
    let qf0 = (y > 0xF0) as u32;
    let q30 = (y > 0x30) as u32;
    let q100 = (y > 0x100) as u32;
    let q8 = (y > 8) as u32;
    let q80 = (y > 0x80) as u32;
    let q280 = (y > 0x280) as u32;
    let (s7, s6, s5, t307, t308);
    if y <= 8 {
        s7 = q50 + 5;
        s6 = qa0 + q10 + if y > 4 { 5 } else { 4 };
        s5 = q20 + qf0 + 4;
        t307 = 4;
        t308 = 5 - ((y < 5) as u32);
    } else {
        s7 = q50 + 6;
        s6 = qa0 + q10 + 5;
        s5 = q20 + qf0 + 5;
        t308 = 5;
        t307 = 5 - ((y < 5) as u32);
    }
    let s4 = q30 + t307 + q100;
    let s3 = t308 + q20 + q100;
    let s2 = q8 + q80 + if y <= 2 { 4 } else { 5 };
    let t309 = if y <= 2 {
        5
    } else {
        6 - ((y < 5) as u32)
    };
    let s1 = t309 + q30 + q280;
    let s0 = t309 + q50;
    [s7, s6, s5, s4, s3, s2, s1, s0]
}

#[allow(clippy::too_many_arguments)]
fn code_sample<const ENC: bool, C: BitCoder>(
    cm: &mut Cm,
    coder: &mut C,
    dm: &mut DmModel,
    s: &mut Frame,
    buf: &mut [u8],
    ch: usize,
    y: usize,
    rates: [u32; 8],
    t: &Tune,
) {
    begin_sample(dm, s);
    match s.plane {
        2 => ctx_green(dm, s, buf),
        1 => ctx_blue(dm, s, buf),
        _ => ctx_red(dm, s, buf),
    }
    let ncap = {
        static N: OnceLock<usize> = OnceLock::new();
        *N.get_or_init(|| std::env::var("R3_NCTX").ok().and_then(|v| v.parse().ok()).unwrap_or(NCTX))
    };
    let nctx = (dm.nctx.max(1) as usize).min(NCTX).min(ncap.max(1));
    let mut buckets = [0u32; NCTX];
    for j in 0..nctx {
        buckets[j] = ((dm.ctx[j] / 11264) as u32) & 0xFFF;
    }

    let px = Frame::sample(buf, s.px_off) as i32;
    let mut val = 0i32;
    let mut c0: usize = 1;
    let mut hist: usize = 1;
    let d = dm.ctx48 as u32;
    let desc = ((d ^ (d >> 8) ^ (d >> 16)) & 0xFF) as usize;
    for k in 0..8usize {
        let chb = ch * 256;
        let mix_sels = if sel_mode() == 1 {
            let u48 = d;
            let bp = k as i32;
            let m = crate::cm3::MIX_SETS - 1;
            [
                (c0 as i32 & m as i32) as usize,
                ((256 + (bp | ((2 * dm.ctx48) & 0x78))) & m as i32) as usize,
                ((384 + (c0 as i32 | (((dm.ctx48 as u16 as i32) << 6) & 0xF00))) & m as i32) as usize,
                ((4480 + (((dm.ctx48 & 0x20 != 0) as i32) | ((u48 >> 11) & 0x1FE) as i32)) & m as i32) as usize,
                ((4992 + ((u48 >> 8) & 0xF) as i32 + ((u48 >> 2) & 0xF) as i32) & m as i32) as usize,
                ((5024 + (dm.ctx48 as u8 as i32)) & m as i32) as usize,
                ((5280 + (((c0 as i32) << bp) | (hist as i32 & ((1 << bp) - 1)))) & m as i32) as usize,
            ]
        } else if sel_mode() == 2 {
            [
                c0 & 255,
                ((((desc >> 3) << 3) | (k & 7)) & 255),
                (((c0 & 0x3F) | ((desc & 3) << 6)) & 255),
                desc,
                ((desc.rotate_left(3)) & 0xFF),
                (((k << 5) | (desc >> 3)) & 255),
                ((c0 & 255) ^ (hist & 255)),
            ]
        } else {
        [
            chb + (c0 & 255),
            chb + ((((desc >> 3) << 3) | (k & 7)) & 255),
            chb + (((c0 & 0x3F) | ((desc & 3) << 6)) & 255),
            chb + desc,
            chb + ((desc.rotate_left(3)) & 0xFF),
            chb + (((k << 5) | (desc >> 3)) & 255),
            chb + ((c0 & 255) ^ (hist & 255)),
        ]
        };
        let apm_sels = if apm_on() { [chb + desc, chb + (c0 & 255)] } else { [0, 0] };
        let rate = if t.dm_rates {
            rates[k]
        } else if k < 4 {
            t.rhi
        } else {
            t.rlo
        };
        let (bit, p) = cm.code_bit::<ENC, C>(
            coder,
            (px >> (7 - k)) & 1,
            &buckets,
            nctx,
            c0,
            mix_sels,
            apm_sels,
            if sel_mode() == 1 { k } else { ch * 8 + k },
            rate,
            t.lr,
        );
        val = (val << 1) | bit;
        c0 = c0 * 2 + bit as usize;
        let wrong = ((p >= 2048) as i32 != bit) as usize;
        hist = ((hist << 1) | wrong) & 0xFF;
    }
    if !ENC {
        buf[s.px_off as usize] = val as u8;
    }
    advance_pixel(s);
    s.px_off += 3;
    let _ = y;
}

#[allow(clippy::too_many_arguments)]
fn walk<const ENC: bool, C: BitCoder>(w: usize, h: usize, buf: &mut [u8], coder: &mut C) {
    let t = tune();
    let mut s = Frame::new(w, h);
    let mut dm = DmModel::new();
    s.plane = 2;
    s.plane_count = -2;
    let mut cm = if std::env::var("R3_INIT").ok().as_deref() == Some("dm") {
        Cm::new_dm()
    } else {
        Cm::new_with_prior(&kinds())
    };
    while s.plane != -1 {
        let ch = (2 - s.plane) as usize;
        s.y = 0;
        s.row_off = s.plane as i64;
        s.green_row_off = s.plane as i64;
        s.prev_plane_a = s.prev_plane;
        s.y_scan = 0;
        s.y_row = 0;
        s.y_next = 1;
        s.y16 = 0;
        s.rate_base = 4;
        s.px_off = s.row_off;
        s.x = 0;
        begin_row(&mut s, buf);
        for y in 0..h {
            let rates = dm_rates(y as i64);
            s.x = 0;
            for x in 0..w {
                s.x = x as i64;
                s.x_next = x as i64 + 1;
                load_neighbours(&mut s, buf);
                code_sample::<ENC, C>(&mut cm, coder, &mut dm, &mut s, buf, ch, y, rates, t);
            }
            if y + 1 < h {
                let ny = y as i64 + 1;
                s.y_next = ny;
                s.y = ny;
                s.y_row = ny;
                s.y_scan = ny;
                s.y16 = 16 * ny;
                s.rate_base = 5 - ((ny < 5) as i32);
                s.row_off += s.stride;
                begin_row(&mut s, buf);
            }
        }
        if std::env::var("R3_STATS").ok().as_deref() == Some("1") {
            let bits = cm.cost;
            eprintln!(
                "plane {} cost {:.0} bits {:.4} bpp",
                s.plane,
                bits,
                bits / (w * h) as f64
            );
            cm.cost = 0.0;
        }
        next_plane(&mut s);
    }
}

pub fn encode_rgb(rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
    let n = w * h;
    let mut buf = vec![0u8; n * 3];
    for i in 0..n {
        buf[i * 3] = rgb[i * 3]; // R
        buf[i * 3 + 1] = rgb[i * 3 + 2]; // B
        buf[i * 3 + 2] = rgb[i * 3 + 1]; // G
    }
    let mut coder = rc::Encoder::new();
    walk::<true, _>(w, h, &mut buf, &mut coder);
    let payload = coder.finish();
    let mut out = Vec::with_capacity(payload.len() + 12);
    out.extend_from_slice(MAGIC);
    out.extend_from_slice(&(w as u32).to_le_bytes());
    out.extend_from_slice(&(h as u32).to_le_bytes());
    out.extend_from_slice(&payload);
    out
}

pub fn decode_rgb(data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
    if data.len() < 12 || &data[0..4] != MAGIC {
        return Err("bad AC13 header".into());
    }
    let w = u32::from_le_bytes(data[4..8].try_into().unwrap()) as usize;
    let h = u32::from_le_bytes(data[8..12].try_into().unwrap()) as usize;
    if w == 0 || h == 0 || w.checked_mul(h).map_or(true, |n| n > 1 << 30) {
        return Err("bad dimensions".into());
    }
    let mut buf = vec![0u8; w * h * 3];
    let mut dec = rc::Decoder::new(&data[12..]);
    walk::<false, _>(w, h, &mut buf, &mut dec);
    let n = w * h;
    let mut rgb = vec![0u8; n * 3];
    for i in 0..n {
        rgb[i * 3] = buf[i * 3];
        rgb[i * 3 + 1] = buf[i * 3 + 2];
        rgb[i * 3 + 2] = buf[i * 3 + 1];
    }
    Ok((rgb, w, h))
}

pub struct R3;

impl Codec for R3 {
    fn name(&self) -> &'static str {
        "r3-deepctx"
    }
    fn encode(&self, rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
        encode_rgb(rgb, w, h)
    }
    fn decode(&self, data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
        decode_rgb(data)
    }
}
