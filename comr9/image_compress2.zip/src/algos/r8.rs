//! Round 8: G→B/R plane pipeline.
//!
//! G is coded first with its own model. B and R then run concurrently: each
//! starts from a clone of the post-G model, and R consumes B one row behind
//! through a row channel, so no shared mutable buffer is needed. B never
//! reads R, so the pipeline is one-way.

use crate::algos::r4::{new_model, run_plane};
use crate::cm4::BitCoder;
use crate::dmctx::DmModel;
use crate::rc;
use crate::Codec;
use std::sync::mpsc;

const MAGIC: &[u8; 4] = b"AC18";

fn chroma_score(rgb: &[u8]) -> u64 {
    let n = rgb.len() / 3;
    if n == 0 {
        return 0;
    }
    let step = (n / 200_000).max(1);
    let mut sum = 0u64;
    let mut cnt = 0u64;
    let mut i = 0;
    while i < n {
        let o = i * 3;
        let g = rgb[o + 1] as i32;
        sum += (rgb[o] as i32 - g).unsigned_abs() as u64;
        sum += (rgb[o + 2] as i32 - g).unsigned_abs() as u64;
        cnt += 1;
        i += step;
    }
    sum / cnt.max(1)
}

fn pipe_off() -> bool {
    static P: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *P.get_or_init(|| std::env::var("ACM_NOPIPE").ok().as_deref() == Some("1"))
}

fn threshold() -> u64 {
    std::env::var("R8_T")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(40)
}

/// Choose the chroma representation. The global chroma score is cheap and
/// decisive at the extremes; only the ambiguous band pays for a trial encode
/// of four quadrant crops (summed, so one unrepresentative region cannot flip
/// the decision on its own).
fn select_res(rgb: &[u8], w: usize, h: usize) -> bool {
    if let Ok(v) = std::env::var("R8_SELECT") {
        match v.as_str() {
            "score" => return chroma_score(rgb) < threshold(),
            "abs" => return false,
            "res" => return true,
            _ => {}
        }
    }
    let t = threshold();
    let score = chroma_score(rgb);
    if score * 4 < t * 3 {
        return true;
    }
    if score > t * 3 / 2 {
        return false;
    }
    let cw = w.min(64).max(8);
    let ch = h.min(64).max(8);
    let xs = [w / 4, w * 3 / 4];
    let ys = [h / 4, h * 3 / 4];
    let mut sum_a = 0usize;
    let mut sum_b = 0usize;
    for &cx in &xs {
        for &cy in &ys {
            let x0 = cx.saturating_sub(cw / 2).min(w - cw);
            let y0 = cy.saturating_sub(ch / 2).min(h - ch);
            let mut crop = Vec::with_capacity(cw * ch * 3);
            for y in 0..ch {
                let s = ((y0 + y) * w + x0) * 3;
                crop.extend_from_slice(&rgb[s..s + cw * 3]);
            }
            sum_a += crate::algos::r4::encode_rgb(&crop, cw, ch).len();
            sum_b += crate::algos::r6::encode_rgb(&crop, cw, ch).len();
        }
    }
    if std::env::var("R8_DEBUG_SEL").ok().as_deref() == Some("1") {
        eprintln!(
            "select: score {} crop {}x{}x4 abs={} res={} -> {}",
            score, cw, ch, sum_a, sum_b,
            if sum_b < sum_a { "res" } else { "abs" }
        );
    }
    sum_b < sum_a
}

fn row_b_bytes(buf: &[u8], w: usize, y: usize) -> Vec<u8> {
    let base = y * w * 3;
    let mut row = Vec::with_capacity(w);
    for x in 0..w {
        row.push(buf[base + x * 3 + 1]);
    }
    row
}

fn patch_b_row(buf: &mut [u8], w: usize, y: usize, row: &[u8]) {
    let base = y * w * 3;
    for x in 0..w {
        buf[base + x * 3 + 1] = row[x];
    }
}

pub fn encode_rgb(rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
    let n = w * h;
    let mut buf = vec![0u8; n * 3];
    for i in 0..n {
        buf[i * 3] = rgb[i * 3];
        buf[i * 3 + 1] = rgb[i * 3 + 2];
        buf[i * 3 + 2] = rgb[i * 3 + 1];
    }
    let use_res = select_res(rgb, w, h);
    if use_res {
        for i in 0..n {
            let g = buf[i * 3 + 2];
            buf[i * 3] = buf[i * 3].wrapping_sub(g);
            buf[i * 3 + 1] = buf[i * 3 + 1].wrapping_sub(g);
        }
    }
    let mut cm_g = new_model();
    let mut dm = DmModel::new();
    let mut enc_g = rc::Encoder::new();
    run_plane::<true, _>(w, h, 2, &mut buf, &mut cm_g, &mut dm, &mut enc_g, None, None);
    let payload_g = enc_g.finish();

    let (payload_b, payload_r) = if pipe_off() {
        let mut cmb = cm_g.clone();
        let mut bb = buf.clone();
        let mut dm = DmModel::new();
        let mut e = rc::Encoder::new();
        run_plane::<true, _>(w, h, 1, &mut bb, &mut cmb, &mut dm, &mut e, None, None);
        let pb = e.finish();
        for y in 0..h {
            let row = row_b_bytes(&bb, w, y);
            patch_b_row(&mut buf, w, y, &row);
        }
        let mut cmr = cm_g.clone();
        let mut dm = DmModel::new();
        let mut e = rc::Encoder::new();
        run_plane::<true, _>(w, h, 0, &mut buf, &mut cmr, &mut dm, &mut e, None, None);
        (pb, e.finish())
    } else {
    let pair = std::thread::scope(|sc| {
        let mut cmb = cm_g.clone();
        let mut cmr = cm_g.clone();
        let mut bb = buf.clone();
        let mut rr = buf.clone();
        let hb = sc.spawn(move || {
            let mut dm = DmModel::new();
            let mut e = rc::Encoder::new();
            run_plane::<true, _>(w, h, 1, &mut bb, &mut cmb, &mut dm, &mut e, None, None);
            e.finish()
        });
        let hr = sc.spawn(move || {
            let mut dm = DmModel::new();
            let mut e = rc::Encoder::new();
            run_plane::<true, _>(w, h, 0, &mut rr, &mut cmr, &mut dm, &mut e, None, None);
            e.finish()
        });
        (hb.join().unwrap(), hr.join().unwrap())
    });
    pair
    };

    let mut out = Vec::with_capacity(payload_g.len() + payload_b.len() + payload_r.len() + 20);
    out.extend_from_slice(MAGIC);
    out.extend_from_slice(&(w as u32).to_le_bytes());
    out.extend_from_slice(&(h as u32).to_le_bytes());
    out.push(use_res as u8);
    for p in [&payload_g, &payload_b, &payload_r] {
        out.extend_from_slice(&(p.len() as u32).to_le_bytes());
    }
    out.extend_from_slice(&payload_g);
    out.extend_from_slice(&payload_b);
    out.extend_from_slice(&payload_r);
    out
}

pub fn decode_rgb(data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
    if data.len() < 25 || &data[0..4] != MAGIC {
        return Err("bad AC18 header".into());
    }
    let w = u32::from_le_bytes(data[4..8].try_into().unwrap()) as usize;
    let h = u32::from_le_bytes(data[8..12].try_into().unwrap()) as usize;
    let use_res = data[12] == 1;
    if w == 0 || h == 0 || w.checked_mul(h).map_or(true, |n| n > 1 << 30) {
        return Err("bad dimensions".into());
    }
    let mut lens = [0usize; 3];
    for (k, l) in lens.iter_mut().enumerate() {
        *l = u32::from_le_bytes(data[13 + 4 * k..17 + 4 * k].try_into().unwrap()) as usize;
    }
    let mut off = 25;
    let mut parts: Vec<&[u8]> = Vec::with_capacity(3);
    for &l in &lens {
        if data.len() < off + l {
            return Err("truncated payload".into());
        }
        parts.push(&data[off..off + l]);
        off += l;
    }
    let (pg, pb, pr) = (parts[0], parts[1], parts[2]);

    let (pg, pb, pr) = (parts[0], parts[1], parts[2]);
    let n = w * h;
    let mut buf = vec![0u8; n * 3];
    let mut cm_g = new_model();
    let mut dm = DmModel::new();
    let mut dec_g = rc::Decoder::new(pg);
    run_plane::<false, _>(w, h, 2, &mut buf, &mut cm_g, &mut dm, &mut dec_g, None, None);

    let buf_final = if pipe_off() {
        let mut cmb = cm_g.clone();
        let mut bb = buf.clone();
        let mut dm = DmModel::new();
        let mut d = rc::Decoder::new(pb);
        run_plane::<false, _>(w, h, 1, &mut bb, &mut cmb, &mut dm, &mut d, None, None);
        for y in 0..h {
            let row = row_b_bytes(&bb, w, y);
            patch_b_row(&mut buf, w, y, &row);
        }
        let mut cmr = cm_g.clone();
        let mut dm = DmModel::new();
        let mut d = rc::Decoder::new(pr);
        run_plane::<false, _>(w, h, 0, &mut buf, &mut cmr, &mut dm, &mut d, None, None);
        buf
    } else {
    let (tx, rx) = mpsc::channel::<Vec<u8>>();
    let buf_b = buf.clone();
    let buf_r = buf.clone();
    let out = std::thread::scope(|sc| {
        let mut cmb = cm_g.clone();
        let mut cmr = cm_g.clone();
        let mut bb = buf_b;
        let hb = sc.spawn(move || {
            let mut dm = DmModel::new();
            let mut d = rc::Decoder::new(pb);
            let mut send = |y: usize, b: &[u8]| {
                let _ = tx.send(row_b_bytes(b, w, y));
            };
            let mut hook = Some(&mut send as &mut dyn FnMut(usize, &[u8]));
            run_plane::<false, _>(w, h, 1, &mut bb, &mut cmb, &mut dm, &mut d, None, hook.take());
            bb
        });
        let mut rr = buf_r;
        let hr = sc.spawn(move || {
            let mut dm = DmModel::new();
            let mut d = rc::Decoder::new(pr);
            let mut have = 0usize;
            let mut patch = |y: usize, b: &mut [u8]| {
                while have <= y {
                    if let Ok(row) = rx.recv() {
                        patch_b_row(b, w, have, &row);
                        have += 1;
                    } else {
                        break;
                    }
                }
            };
            let mut hook = Some(&mut patch as &mut dyn FnMut(usize, &mut [u8]));
            run_plane::<false, _>(w, h, 0, &mut rr, &mut cmr, &mut dm, &mut d, hook.take(), None);
            rr
        });
        (hb.join().unwrap(), hr.join().unwrap())
    });
    out.1
    };
    let mut rgb = vec![0u8; n * 3];
    for i in 0..n {
        let g = buf_final[i * 3 + 2];
        if use_res {
            rgb[i * 3] = buf_final[i * 3].wrapping_add(g);
            rgb[i * 3 + 1] = g;
            rgb[i * 3 + 2] = buf_final[i * 3 + 1].wrapping_add(g);
        } else {
            rgb[i * 3] = buf_final[i * 3];
            rgb[i * 3 + 1] = g;
            rgb[i * 3 + 2] = buf_final[i * 3 + 1];
        }
    }
    Ok((rgb, w, h))
}

pub struct R8;

impl Codec for R8 {
    fn name(&self) -> &'static str {
        "r8-pipeline"
    }
    fn encode(&self, rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
        encode_rgb(rgb, w, h)
    }
    fn decode(&self, data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
        decode_rgb(data)
    }
}
