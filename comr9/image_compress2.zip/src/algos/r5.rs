//! Round 5: stripe-parallel wrapper around the r4 codec.
//!
//! The image is cut into horizontal stripes, each compressed independently
//! with the full r4 model in its own thread. Decoding is trivially parallel
//! too. This trades a little ratio (per-stripe model warm-up) for near-linear
//! wall-clock speed-up.

use crate::algos::r7;
use crate::Codec;

const MAGIC: &[u8; 4] = b"AC15";

fn tile_count(n: usize, h: usize) -> usize {
    let cores = std::thread::available_parallelism()
        .map(|v| v.get())
        .unwrap_or(4);
    let auto = (n / 500_000).clamp(2, 4).min(cores).min(h.max(1));
    let k = std::env::var("R5_TILES")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(auto);
    k.clamp(1, h.max(1))
}

fn stripe_rows(h: usize, k: usize, t: usize) -> (usize, usize) {
    let rows = (h + k - 1) / k;
    let y = (t * rows).min(h);
    (y, rows.min(h - y))
}

pub fn encode_rgb(rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
    let k = tile_count(w * h, h);
    let results: Vec<Vec<u8>> = std::thread::scope(|sc| {
        let handles: Vec<_> = (0..k)
            .filter_map(|t| {
                let (y, hh) = stripe_rows(h, k, t);
                if hh == 0 {
                    return None;
                }
                let stripe = rgb[y * w * 3..(y + hh) * w * 3].to_vec();
                Some(sc.spawn(move || r7::encode_rgb(&stripe, w, hh)))
            })
            .collect();
        handles.into_iter().map(|h| h.join().unwrap()).collect()
    });
    let mut out = Vec::new();
    out.extend_from_slice(MAGIC);
    out.extend_from_slice(&(w as u32).to_le_bytes());
    out.extend_from_slice(&(h as u32).to_le_bytes());
    out.extend_from_slice(&(k as u32).to_le_bytes());
    for r in &results {
        out.extend_from_slice(&(r.len() as u32).to_le_bytes());
    }
    for r in &results {
        out.extend_from_slice(r);
    }
    out
}

pub fn decode_rgb(data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
    if data.len() < 16 || &data[0..4] != MAGIC {
        return Err("bad AC15 header".into());
    }
    let w = u32::from_le_bytes(data[4..8].try_into().unwrap()) as usize;
    let h = u32::from_le_bytes(data[8..12].try_into().unwrap()) as usize;
    let k = u32::from_le_bytes(data[12..16].try_into().unwrap()) as usize;
    if w == 0 || h == 0 || k == 0 || k > h {
        return Err("bad dimensions".into());
    }
    let mut off = 16;
    if data.len() < off + 4 * k {
        return Err("truncated lengths".into());
    }
    let mut lens = Vec::with_capacity(k);
    for _ in 0..k {
        let n = u32::from_le_bytes(data[off..off + 4].try_into().unwrap()) as usize;
        lens.push(n);
        off += 4;
    }
    let mut parts = Vec::with_capacity(k);
    for &n in &lens {
        if data.len() < off + n {
            return Err("truncated stripe".into());
        }
        parts.push(&data[off..off + n]);
        off += n;
    }
    let rows: Vec<(usize, usize)> = (0..k).map(|t| stripe_rows(h, k, t)).collect();
    let decoded: Vec<(Vec<u8>, usize, usize)> = std::thread::scope(|sc| {
        let handles: Vec<_> = parts
            .iter()
            .map(|p| sc.spawn(move || r7::decode_rgb(p)))
            .collect();
        handles
            .into_iter()
            .map(|h| h.join().unwrap())
            .collect::<Result<Vec<_>, _>>()
            .unwrap_or_default()
    });
    if decoded.len() != k {
        return Err("stripe decode failed".into());
    }
    let mut rgb = vec![0u8; w * h * 3];
    for (t, (px, sw, sh)) in decoded.into_iter().enumerate() {
        let (y, hh) = rows[t];
        if sw != w || sh != hh {
            return Err("stripe dimension mismatch".into());
        }
        rgb[y * w * 3..(y + hh) * w * 3].copy_from_slice(&px);
    }
    Ok((rgb, w, h))
}

pub struct R5;

impl Codec for R5 {
    fn name(&self) -> &'static str {
        "r5-parallel"
    }
    fn encode(&self, rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
        encode_rgb(rgb, w, h)
    }
    fn decode(&self, data: &[u8]) -> Result<(Vec<u8>, usize, usize), String> {
        decode_rgb(data)
    }
}
