//! 12-bit-bucket full-tree context mixing for 48 contexts (deepmix's 44
//! plus four anime-specific ones). One 256-node tree per (context, bucket):
//! 48 * 4096 * 256 counters (~100 MB) per model.

use crate::rc;

pub const NCTX: usize = 48;
pub const BUCKET_BITS: u32 = 12;
pub const NBUCKETS: usize = 1 << BUCKET_BITS;
pub const NODES: usize = 256;

fn bucket_bits() -> u32 {
    static B: std::sync::OnceLock<u32> = std::sync::OnceLock::new();
    *B.get_or_init(|| {
        std::env::var("ACM_BUCKET_BITS")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(BUCKET_BITS)
            .clamp(4, BUCKET_BITS)
    })
}

fn ctx_stride() -> usize {
    static S: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    *S.get_or_init(|| {
        std::env::var("ACM_NCTX")
            .or_else(|_| std::env::var("R4_NCTX"))
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(NCTX)
            .clamp(1, NCTX)
    })
}

fn stats_on() -> bool {
    static S: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *S.get_or_init(|| std::env::var("R4_STATS").ok().as_deref() == Some("1"))
}
/// Table layout: [bucket][c0][context]; all contexts for one tree node are
/// contiguous, which keeps the 48 counter reads of a decision in two cache
/// lines.
pub const TBL_LEN: usize = NBUCKETS * NODES * NCTX;

/// First-layer mixer selectors: 3 channels x 8 bit positions x 16 classes.
pub const MIX_SETS: usize = 8192;
/// Four first-layer mixers, each with NCTX+1 weights per selector.
pub const N_MIX1: usize = 7;
pub const W1_LEN: usize = N_MIX1 * MIX_SETS * (NCTX + 1);
/// Second layer: 3 channels x 8 bit positions, 5 inputs (4 + bias).
pub const W2_SETS: usize = 3 * 8;
pub const W2_LEN: usize = W2_SETS * (N_MIX1 + 1);
pub const APM_ROWS: usize = 3 * 256;
pub const APM_W: usize = 33;
pub const RUN_CTX: usize = 128;

pub trait BitCoder {
    fn code(&mut self, bit: i32, p: i32) -> i32;
}

impl BitCoder for rc::Encoder {
    #[inline(always)]
    fn code(&mut self, bit: i32, p: i32) -> i32 {
        self.encode(bit, p);
        bit
    }
}

impl<'a> BitCoder for rc::Decoder<'a> {
    #[inline(always)]
    fn code(&mut self, _bit: i32, p: i32) -> i32 {
        self.decode(p)
    }
}

fn apm_mode() -> bool {
    static A: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *A.get_or_init(|| std::env::var("R3_APM").map(|v| v != "0").unwrap_or(false))
}

fn delta_mode() -> bool {
    static D: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *D.get_or_init(|| std::env::var("R3_DELTAP").map(|v| v == "1").unwrap_or(false))
}

fn prefetch_mode() -> usize {
    static P: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    *P.get_or_init(|| {
        std::env::var("ACM_PREFETCH")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(1)
    })
}

fn apm_weight() -> i32 {
    static W: std::sync::OnceLock<i32> = std::sync::OnceLock::new();
    *W.get_or_init(|| {
        std::env::var("ACM_APM_W")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(3)
    })
}

fn upd_count() -> usize {
    static U: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    *U.get_or_init(|| {
        std::env::var("ACM_UPD")
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .unwrap_or(NCTX)
            .clamp(1, NCTX)
    })
}

fn mix_count() -> usize {
    static M: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    *M.get_or_init(|| {
        std::env::var("ACM_MIX")
            .or_else(|_| std::env::var("R4_MIX"))
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .unwrap_or(N_MIX1)
            .clamp(1, N_MIX1)
    })
}

fn stage_mult() -> [i32; N_MIX1] {
    static M: std::sync::OnceLock<[i32; N_MIX1]> = std::sync::OnceLock::new();
    *M.get_or_init(|| {
        match std::env::var("ACM_MULT").or_else(|_| std::env::var("R3_MULT")) {
            Ok(v) if v == "0" => [1; N_MIX1],
            Ok(v) => {
                let mut a = [1i32; N_MIX1];
                for (i, part) in v.split(',').take(N_MIX1).enumerate() {
                    a[i] = part.parse().unwrap_or(1);
                }
                a
            }
            Err(_) => [3, 9, 36, 27, 36, 54, 9],
        }
    })
}

#[derive(Clone)]
pub struct Cm {
    pub nmix: usize,
    pub apm_now: bool,
    pub apm_w: i32,
    pub tbl: Vec<i16>,
    pub w1: Vec<i32>,
    pub w2: Vec<i32>,
    pub apm1: Vec<u16>,
    pub apm2: Vec<u16>,
    pub run_p: [u16; RUN_CTX],
    pub stretch: [i16; 4096],
    pub squash: [i16; 4095],
    pub cost: f64,
    pub cost_tbl: [f32; 4096],
    pub bmask: usize,
    pub nbuckets: usize,
    pub stride: usize,
}

#[inline(always)]
fn apm_apply(apm: &[u16], ctx: usize, p: i32) -> i32 {
    let idx = ((p >> 7) as usize).min(31);
    let frac = (p & 127) as i32;
    let base = ctx * APM_W + idx;
    let a = apm[base] as i32;
    let b = apm[base + 1] as i32;
    (a * (128 - frac) + b * frac) >> 11
}

#[inline(always)]
fn apm_update(apm: &mut [u16], ctx: usize, p: i32, bit: i32) {
    let idx = ((p >> 7) as usize).min(31);
    let frac = (p & 127) as i32;
    let base = ctx * APM_W + idx;
    let target = bit << 16;
    let a = apm[base] as i32;
    let b = apm[base + 1] as i32;
    let da = ((target - a) * (128 - frac)) >> 13;
    let db = ((target - b) * frac) >> 13;
    apm[base] = (a + da).clamp(0, 65535) as u16;
    apm[base + 1] = (b + db).clamp(0, 65535) as u16;
}

fn prior_scale() -> i32 {
    static S: std::sync::OnceLock<i32> = std::sync::OnceLock::new();
    *S.get_or_init(|| {
        std::env::var("R3_PRIOR")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(35)
    })
}

impl Cm {
    pub fn new() -> Self {
        let mut stretch = [0i16; 4096];
        for (p, s) in stretch.iter_mut().enumerate() {
            let x = (p as f64 + 0.5) / (4096.0 - p as f64 - 0.5);
            let v = (x.ln() * 256.0).round() as i32;
            *s = v.clamp(-2047, 2047) as i16;
        }
        let mut squash = [-1i16; 4095];
        for (p, &s) in stretch.iter().enumerate() {
            let d = (s as i32 + 2047) as usize;
            if squash[d] < 0 {
                squash[d] = (p as i16).max(1);
            }
        }
        let mut last = 1i16;
        for v in squash.iter_mut() {
            if *v < 0 {
                *v = last;
            } else {
                last = *v;
            }
        }

        let mut w1 = vec![0i32; W1_LEN];
        for set in 0..(N_MIX1 * MIX_SETS) {
            let base = set * (NCTX + 1);
            w1[base] = 49152;
            for c in 1..NCTX {
                w1[base + c] = 1024;
            }
        }
        let mut w2 = vec![0i32; W2_LEN];
        for set in 0..W2_SETS {
            for m in 0..N_MIX1 {
                w2[set * (N_MIX1 + 1) + m] = 16384;
            }
        }

        let mut apm1 = vec![0u16; APM_ROWS * APM_W];
        let mut apm2 = vec![0u16; APM_ROWS * APM_W];
        for row in 0..APM_ROWS {
            for i in 0..APM_W {
                let center = (i * 128 + 64).min(4095);
                let v = ((center << 4) as u32).min(65535) as u16;
                apm1[row * APM_W + i] = v;
                apm2[row * APM_W + i] = v;
            }
        }

        let mut cost_tbl = [0f32; 4096];
        for (i, v) in cost_tbl.iter_mut().enumerate() {
            let pp = (i as f64 / 4096.0).clamp(1e-6, 1.0 - 1e-6);
            *v = -(pp.log2()) as f32;
        }

        let mut run_p = [0u16; RUN_CTX];
        for v in run_p.iter_mut() {
            *v = 50000;
        }

        let bbits = bucket_bits();
        let nbuckets = 1usize << bbits;
        let bmask = nbuckets - 1;
        let stride = ctx_stride();
        Cm {
            nmix: mix_count(),
            apm_now: apm_mode(),
            apm_w: apm_weight(),
            tbl: vec![0i16; nbuckets * NODES * stride],
            w1,
            w2,
            apm1,
            apm2,
            run_p,
            stretch,
            squash,
            cost: 0.0,
            cost_tbl,
            bmask,
            nbuckets,
            stride,
        }
    }

    /// Predict and code one bit, then adapt all model state.
    #[allow(clippy::too_many_arguments)]
    #[inline(always)]
    pub fn code_bit<const ENC: bool, C: BitCoder>(
        &mut self,
        coder: &mut C,
        bit_in: i32,
        buckets: &[u32; NCTX],
        nctx: usize,
        c0: usize,
        mix_sels: [usize; N_MIX1],
        apm_sels: [usize; 2],
        w2_sel: usize,
        rate: u32,
        lr: i32,
    ) -> (i32, i32) {
        let nctx = nctx.min(NCTX);
        let mut idx = [0u32; NCTX];
        let mut st = [0i16; NCTX];
        unsafe {
            let tbl = self.tbl.as_ptr();
            for c in 0..nctx {
                let id = ((((buckets[c] as usize) & self.bmask) << 8) | c0) * self.stride + c;
                idx[c] = id as u32;
                let cv = *tbl.add(id) as i32;
                st[c] = (cv >> 2) as i16;
            }
        }

        // First layer: mixers with different selectors (count is tunable).
        let nmix = self.nmix;
        let mut p1 = [2048i32; N_MIX1];
        let mut d1 = [0i32; N_MIX1];
        for m in 0..nmix {
            let base = (m * MIX_SETS + mix_sels[m]) * (NCTX + 1);
            let mut sum: i64 = 0;
            unsafe {
                for c in 0..nctx {
                    sum += (*self.w1.get_unchecked(base + c) * st[c] as i32) as i64;
                }
            }
            let dot = ((sum >> 16) as i32).clamp(-2047, 2047);
            d1[m] = dot;
            p1[m] = unsafe { *self.squash.get_unchecked((dot + 2047) as usize) } as i32;
        }

        // Second layer over the four first-layer outputs.
        let w2b = w2_sel * (N_MIX1 + 1);
        let mut sum2: i64 = 0;
        for m in 0..nmix {
            sum2 += (self.w2[w2b + m] * d1[m]) as i64;
        }
        let dot2 = ((sum2 >> 16) as i32).clamp(-2047, 2047);
        let p2 = unsafe { *self.squash.get_unchecked((dot2 + 2047) as usize) } as i32;

        let apm_on = self.apm_now;
        let p = if apm_on {
            let pa = apm_apply(&self.apm1, apm_sels[0], p2);
            let pb = apm_apply(&self.apm2, apm_sels[1], pa);
            match self.apm_w {
                1 => ((3 * p2 + pa + 2) >> 2).clamp(1, 4095),
                2 => ((p2 + pa + 1) >> 1).clamp(1, 4095),
                _ => ((p2 + pa + 2 * pb + 2) >> 2).clamp(1, 4095),
            }
        } else {
            p2
        };

        let bit = coder.code(if ENC { bit_in } else { 0 }, p);
        #[cfg(target_arch = "x86_64")]
        {
            let pf = prefetch_mode();
            if pf > 0 && c0 < 128 {
                let nc0 = (c0 << 1) | (bit as usize);
                unsafe {
                    let tp = self.tbl.as_ptr();
                    for c in 0..nctx {
                        let idx = ((((buckets[c] as usize) & self.bmask) << 8) | nc0) * self.stride + c;
                        let ptr = tp.add(idx) as *const i8;
                        core::arch::x86_64::_mm_prefetch(ptr, core::arch::x86_64::_MM_HINT_T0);
                        if pf > 1 {
                            core::arch::x86_64::_mm_prefetch(ptr.add(64), core::arch::x86_64::_MM_HINT_T0);
                        }
                    }
                }
            }
        }
        if stats_on() {
            self.cost += if bit != 0 { self.cost_tbl[p as usize] as f64 } else { self.cost_tbl[(4096 - p) as usize] as f64 };
        }

        // First-layer weight updates (each trained on its own output).
        let mult = stage_mult();
        for m in 0..nmix {
            let base = (m * MIX_SETS + mix_sels[m]) * (NCTX + 1);
            let err = ((bit << 12) - p1[m]) * mult[m];
            unsafe {
                for c in 0..nctx {
                    let d = (err * st[c] as i32 * lr) >> 16;
                    *self.w1.get_unchecked_mut(base + c) += d;
                }
            }
        }
        let err2 = (bit << 12) - p2;
        for m in 0..nmix {
            let d = (err2 * d1[m] * lr) >> 16;
            self.w2[w2b + m] += d;
            let w = &mut self.w2[w2b + m];
            if *w > (1 << 19) {
                *w = 1 << 19;
            } else if *w < -(1 << 19) {
                *w = -(1 << 19);
            }
        }

        let pd = if delta_mode() { p2 } else { p };
        let delta = (((bit << 12) + ((1 << rate) >> 1) - 1 - pd) >> rate) as i32;
        if delta != 0 {
            let nupd = upd_count().min(nctx);
            unsafe {
                let tbl = self.tbl.as_mut_ptr();
                for c in 0..nupd {
                    let ip = idx[c] as usize;
                    let cv = *tbl.add(ip) as i32 + delta;
                    *tbl.add(ip) = cv.clamp(-4095, 4095) as i16;
                }
            }
        }

        if apm_on {
            let pa = apm_apply(&self.apm1, apm_sels[0], p2);
            apm_update(&mut self.apm1, apm_sels[0], p2, bit);
            apm_update(&mut self.apm2, apm_sels[1], pa, bit);
        }

        (bit, p)
    }

    #[inline(always)]
    pub fn code_run<const ENC: bool, C: BitCoder>(
        &mut self,
        coder: &mut C,
        cont: i32,
        ctx: usize,
    ) -> i32 {
        let p16 = self.run_p[ctx] as i32;
        let p = (p16 >> 4).clamp(1, 4095);
        let bit = coder.code(if ENC { cont } else { 0 }, p);
        let np = p16 + (((bit << 16) - p16) >> 5);
        self.run_p[ctx] = np.clamp(1, 65535) as u16;
        bit
    }
}

impl Cm {
    /// Model pre-trained with the reference initialiser (deepmix-style).
    pub fn new_dm() -> Self {
        let mut cm = Self::new();
        if cm.nbuckets == 4096 && cm.stride == NCTX {
            crate::dmpri::init(&mut cm.tbl, NCTX);
        }
        cm
    }

    /// Build a model whose contexts are pre-trained so every 12-bit bucket
    /// starts out predicting its own sample value. `kinds[c]` selects the
    /// prior strength class (0 = none, 1 = generic 12-bit prediction).
    pub fn new_with_prior(kinds: &[u8; NCTX]) -> Self {
        let mut cm = Self::new();
        let scale = prior_scale();
        for c in 0..cm.stride {
            let kind = kinds[c];
            let strength: i32 = match kind {
                1 => 1700 * scale / 100,
                2 => 1100 * scale / 100,
                3 => 700 * scale / 100,
                _ => 0,
            };
            if strength <= 0 {
                continue;
            }
            for b in 0..cm.nbuckets {
                let pred = b;
                let mut node = 1usize;
                for k in 0..8 {
                    let bit = (pred >> (7 - k)) & 1;
                    let idx = ((b << 8) | node) * cm.stride + c;
                    cm.tbl[idx] = if bit == 1 { strength as i16 } else { -(strength as i16) };
                    node = node * 2 + bit;
                }
            }
        }
        cm
    }
}

impl Default for Cm {
    fn default() -> Self {
        Self::new()
    }
}
