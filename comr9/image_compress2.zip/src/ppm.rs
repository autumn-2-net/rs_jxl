//! Minimal binary PPM (P6, maxval 255) reader/writer.

use std::io;

/// Read a binary PPM, returning interleaved RGB (`w*h*3` bytes).
pub fn read_ppm(data: &[u8]) -> io::Result<(Vec<u8>, usize, usize)> {
    let mut pos = 0usize;
    let mut fields: Vec<String> = Vec::with_capacity(4);
    while fields.len() < 4 {
        loop {
            if pos >= data.len() {
                return Err(io::Error::new(io::ErrorKind::InvalidData, "truncated ppm header"));
            }
            let c = data[pos];
            if c == b'#' {
                while pos < data.len() && data[pos] != b'\n' {
                    pos += 1;
                }
            } else if c.is_ascii_whitespace() {
                pos += 1;
            } else {
                break;
            }
        }
        let start = pos;
        while pos < data.len() && !data[pos].is_ascii_whitespace() {
            pos += 1;
        }
        fields.push(String::from_utf8_lossy(&data[start..pos]).into_owned());
    }
    if fields[0] != "P6" {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "not a P6 ppm"));
    }
    let w: usize = fields[1]
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "bad width"))?;
    let h: usize = fields[2]
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "bad height"))?;
    let maxval: usize = fields[3]
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "bad maxval"))?;
    if maxval != 255 {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "only maxval 255 supported"));
    }
    // exactly one whitespace byte separates the header from the raster
    if pos >= data.len() || !data[pos].is_ascii_whitespace() {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "missing raster"));
    }
    pos += 1;
    let need = w * h * 3;
    if data.len() < pos + need {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "truncated raster"));
    }
    Ok((data[pos..pos + need].to_vec(), w, h))
}

/// Serialize interleaved RGB as a P6 PPM.
pub fn write_ppm(rgb: &[u8], w: usize, h: usize) -> Vec<u8> {
    let mut out = Vec::with_capacity(w * h * 3 + 32);
    out.extend_from_slice(b"P6\n");
    out.extend_from_slice(format!("{w} {h}\n255\n").as_bytes());
    out.extend_from_slice(rgb);
    out
}
