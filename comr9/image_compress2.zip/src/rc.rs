//! Carry-less binary interval coder with 12-bit probabilities.
//!
//! Same coding scheme as the reference `deepmix` coder (public domain):
//! `p` is the probability that the coded bit is 1, scaled to 0..4096.
//! Whole bytes are emitted as soon as the top bytes of the low/high bounds
//! agree, so no carry propagation is needed.

pub struct Encoder {
    pub out: Vec<u8>,
    x1: u32,
    x2: u32,
}

impl Encoder {
    pub fn new() -> Self {
        Encoder { out: Vec::new(), x1: 0, x2: 0xFFFF_FFFF }
    }

    #[inline(always)]
    pub fn encode(&mut self, bit: i32, p: i32) {
        let x1 = self.x1;
        let x2 = self.x2;
        let diff = x2.wrapping_sub(x1);
        let hi = diff >> 12;
        let lo = diff & 0xFFF;
        let xmid = x1
            .wrapping_add(hi.wrapping_mul(p as u32))
            .wrapping_add((lo.wrapping_mul(p as u32)) >> 12);

        let (mut x1, mut x2) = (x1, x2);
        if bit != 0 {
            x2 = xmid;
        } else {
            x1 = xmid.wrapping_add(1);
        }

        if (x1 ^ x2) & 0xFF00_0000 == 0 {
            loop {
                self.out.push((x2 >> 24) as u8);
                x1 <<= 8;
                x2 = (x2 << 8) | 0xFF;
                if (x1 ^ x2) & 0xFF00_0000 != 0 {
                    break;
                }
            }
        }
        self.x1 = x1;
        self.x2 = x2;
    }

    #[inline]
    pub fn finish(mut self) -> Vec<u8> {
        self.out.push((self.x1 >> 24) as u8);
        self.out
    }
}

impl Default for Encoder {
    fn default() -> Self {
        Self::new()
    }
}

pub struct Decoder<'a> {
    pub data: &'a [u8],
    pub pos: usize,
    x1: u32,
    x2: u32,
    x: u32,
}

impl<'a> Decoder<'a> {
    pub fn new(data: &'a [u8]) -> Self {
        let mut d = Decoder { data, pos: 0, x1: 0, x2: 0xFFFF_FFFF, x: 0 };
        let mut x = 0u32;
        for _ in 0..4 {
            x = (x << 8) | d.next_byte();
        }
        d.x = x;
        d
    }

    #[inline(always)]
    fn next_byte(&mut self) -> u32 {
        let b = if self.pos < self.data.len() {
            self.data[self.pos]
        } else {
            0xFF
        };
        self.pos += 1;
        b as u32
    }

    #[inline(always)]
    pub fn decode(&mut self, p: i32) -> i32 {
        let diff = self.x2.wrapping_sub(self.x1);
        let hi = diff >> 12;
        let lo = diff & 0xFFF;
        let xmid = self
            .x1
            .wrapping_add(hi.wrapping_mul(p as u32))
            .wrapping_add((lo.wrapping_mul(p as u32)) >> 12);

        let bit = if self.x <= xmid { 1 } else { 0 };
        if bit != 0 {
            self.x2 = xmid;
        } else {
            self.x1 = xmid.wrapping_add(1);
        }
        while (self.x1 ^ self.x2) & 0xFF00_0000 == 0 {
            self.x1 <<= 8;
            self.x2 = (self.x2 << 8) | 0xFF;
            let nb = self.next_byte();
            self.x = (self.x << 8) | nb;
        }
        bit
    }
}
