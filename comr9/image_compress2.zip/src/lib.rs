//! Experimental lossless image codecs for anime / illustration content.

pub mod algos;
pub mod cm;
pub mod cm2;
pub mod cm3;
pub mod cm4;
pub mod dmctx;
pub mod dmpri;
pub mod ppm;
pub mod rc;

/// A lossless RGB image codec.
pub trait Codec {
    fn name(&self) -> &'static str;
    fn encode(&self, rgb: &[u8], w: usize, h: usize) -> Vec<u8>;
    fn decode(&self, data: &[u8]) -> Result<(Vec<u8>, usize, usize), String>;
}

/// All registered codecs, in benchmark order.
pub fn codecs() -> Vec<Box<dyn Codec>> {
    vec![Box::new(algos::r1::R1), Box::new(algos::r2::R2), Box::new(algos::r3::R3), Box::new(algos::r4::R4), Box::new(algos::r5::R5), Box::new(algos::r6::R6), Box::new(algos::r7::R7), Box::new(algos::r8::R8), Box::new(algos::r9::R9)]
}
