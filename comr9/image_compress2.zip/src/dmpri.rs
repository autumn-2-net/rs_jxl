//! deepmix's counter-table pre-training, parameterised by the context stride.
//!
//! The reference initialiser simulates the bit tree for a range of sample
//! values around every state and accumulates graded evidence into the slots
//! those states would visit. The formulas are the reference's, with the
//! hard-coded 44-word stride replaced by `nc`.

#[inline]
fn add(t: &mut [i16], idx: usize, delta: i16) {
    t[idx] = t[idx].wrapping_add(delta);
}

pub fn init(t: &mut [i16], nc: usize) {
    debug_assert_eq!(t.len(), nc * 4096 * 256);
    for x in t.iter_mut() {
        *x = 0;
    }
    let big = nc * 4096; // 44 * 4096 in the reference
    let mid = nc * 2048; // 44 * 2048
    let far = nc * 65536;

    for s in 0usize..255 {
        let t310 = s << 8;
        let t311 = (s & 0xF8) | 0x100;
        let t312 = big * (s & 0xF8);
        let result_base = big * (s & 0xFC) + (nc - 1);
        let t10 = mid * t311 + 26;

        for i in -11i32..=11 {
            let t313 = i + s as i32;
            if (t313 as u32) > 0xFF {
                continue;
            }
            let mut c0: u8 = 1;
            for lev in (0..=7).rev() {
                let bit = ((t313 >> lev) & 1) as i32;
                let delta = ((128 - i * i) * (32 * bit - 16)) as i16;

                let slot = (c0 as usize) | t310;
                let base = nc * slot;
                for w in 0..24 {
                    add(t, base + w, delta);
                }
                add(t, base + nc - 1, delta);
                add(t, base + far + 15, delta);

                if s & 3 == 0 {
                    add(t, base + 29, delta);
                    add(t, base + 29 + nc * 256, delta);
                    add(t, base + 29 + nc * 512, delta);
                    add(t, base + 29 + nc * 768, delta);
                    add(t, base + 34, delta);
                }
                if s & 1 == 0 {
                    for w in 28..=42 {
                        add(t, base + w, delta);
                    }
                    add(t, base + 28 + nc * 256, delta);

                    let s2 = (c0 as usize) | (s << 7);
                    let e1 = nc * s2 + t312;
                    add(t, e1 + 24, delta);
                    add(t, e1 + 25, delta);
                    let e2 = nc * s2 + big * ((s as u8 ^ 8) & 0xF8) as usize;
                    add(t, e2 + 24, delta);
                    add(t, e2 + 25, delta);

                    if s & 3 == 0 {
                        let s3 = (c0 as usize) | (s << 6);
                        add(t, t10 + nc * s3, delta);
                        add(t, result_base + nc * s3, delta);
                        if s & 0xF == 0 {
                            let slot = big * ((s >> 4) | (s & 0xF0)) + 30 + nc * ((16 * s) | c0 as usize);
                            add(t, slot, delta);
                        }
                    }
                }

                c0 = (bit as u8).wrapping_add(c0.wrapping_mul(2));
            }
        }
    }
}
